=== TrendingVerse Ads ===
Version: 1.0.3
Requires at least: 5.0
Tested up to: 6.5
Requires PHP: 7.4

== Description ==
Automatically fetches and injects monetization ads from TrendingVerse CMS.
Includes first-party audience tracking and lead capture for targeted advertising.
Self-updating — updates automatically when new versions are released.

== Installation ==
1. Upload trendingverse-ads folder to /wp-content/plugins/
2. Activate plugin
3. Settings → TrendingVerse Ads → Enter API Key → Save & Connect

== What's included ==
- Programmatic ad injection (header, in-content, footer)
- Gambling/adult content filter
- Auto-refresh ad codes every hour
- First-party audience tracking (pageviews, scroll depth, time on page)
- Lead capture popup (name, email, city, gender, age)
- Anonymous reader fingerprinting
- Self-update mechanism

== Changelog ==
= 1.0.3 = Audience tracking + lead capture popup + gambling filter + auto-update
= 1.0.2 = Auto-update mechanism added
= 1.0.1 = Fixed API endpoint URL
= 1.0.0 = Initial release
