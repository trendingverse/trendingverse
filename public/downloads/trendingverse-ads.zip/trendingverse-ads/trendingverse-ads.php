<?php
/**
 * Plugin Name: TrendingVerse Ads
 * Plugin URI: https://trendingverse-pages.pages.dev
 * Description: Automatically fetches and injects monetization ads from TrendingVerse CMS. Includes audience tracking, scroll depth, and Google One Tap email capture.
 * Version: 1.0.5
 * Author: TrendingVerse
 * Author URI: https://trendingverse-pages.pages.dev
 * License: GPL2
 */

if (!defined('ABSPATH')) exit;

define('TV_ADS_VERSION',    '1.0.5');
define('TV_ADS_API',        'https://trendingverse-pages.pages.dev/api/tvads/plugin/config');
define('TV_ADS_UPDATE_URL', 'https://trendingverse-pages.pages.dev/api/plugin/update-check');
define('TV_ADS_DOWNLOAD',   'https://trendingverse-pages.pages.dev/api/plugin/download');
define('TV_ADS_CACHE_KEY',  'tv_ads_cache');
define('TV_ADS_CACHE_TTL',  3600);

// ── AUTO-UPDATE ──────────────────────────────────────────────────

add_filter('pre_set_site_transient_update_plugins', 'tv_ads_check_update');
function tv_ads_check_update($transient) {
    if (empty($transient->checked)) return $transient;
    $response = wp_remote_get(TV_ADS_UPDATE_URL, ['timeout' => 10, 'headers' => ['Accept' => 'application/json']]);
    if (is_wp_error($response)) return $transient;
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($data['version'])) return $transient;
    if (version_compare(TV_ADS_VERSION, $data['version'], '<')) {
        $transient->response['trendingverse-ads/trendingverse-ads.php'] = (object) [
            'slug'        => 'trendingverse-ads',
            'plugin'      => 'trendingverse-ads/trendingverse-ads.php',
            'new_version' => $data['version'],
            'url'         => 'https://trendingverse-pages.pages.dev',
            'package'     => TV_ADS_DOWNLOAD,
        ];
    }
    return $transient;
}

add_filter('plugins_api', 'tv_ads_plugin_info', 20, 3);
function tv_ads_plugin_info($result, $action, $args) {
    if ($action !== 'plugin_information') return $result;
    if (!isset($args->slug) || $args->slug !== 'trendingverse-ads') return $result;
    $response = wp_remote_get(TV_ADS_UPDATE_URL . '?action=info', ['timeout' => 10, 'headers' => ['Accept' => 'application/json']]);
    if (is_wp_error($response)) return $result;
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($data)) return $result;
    return (object) [
        'name'          => $data['name']         ?? 'TrendingVerse Ads',
        'slug'          => 'trendingverse-ads',
        'version'       => $data['version']      ?? TV_ADS_VERSION,
        'author'        => $data['author']        ?? 'TrendingVerse',
        'last_updated'  => $data['last_updated']  ?? '',
        'requires'      => $data['requires']      ?? '5.0',
        'tested'        => $data['tested']        ?? '6.5',
        'download_link' => TV_ADS_DOWNLOAD,
        'sections'      => $data['sections']      ?? [],
    ];
}

// ── ADMIN SETTINGS ───────────────────────────────────────────────

add_action('admin_menu', function () {
    add_options_page('TrendingVerse Ads', 'TrendingVerse Ads', 'manage_options', 'trendingverse-ads', 'tv_ads_settings_page');
});

add_action('admin_init', function () {
    register_setting('tv_ads_settings', 'tv_ads_publisher_key');
    register_setting('tv_ads_settings', 'tv_ads_enabled');
    register_setting('tv_ads_settings', 'tv_ads_tracking_enabled');
    register_setting('tv_ads_settings', 'tv_ads_google_client_id');
});

function tv_ads_settings_page() {
    $key              = get_option('tv_ads_publisher_key', '');
    $enabled          = get_option('tv_ads_enabled', '1');
    $tracking_enabled = get_option('tv_ads_tracking_enabled', '1');
    $google_client_id = get_option('tv_ads_google_client_id', '');
    $status           = tv_ads_test_connection($key);
    $refreshed        = isset($_GET['refreshed']);
    ?>
    <div class="wrap">
        <h1>🎯 TrendingVerse Ads
            <span style="font-size:12px;background:#111;color:#fff;padding:2px 8px;border-radius:20px;font-weight:400;">v<?php echo TV_ADS_VERSION; ?></span>
        </h1>
        <p style="color:#666;">Automatically injects monetization ads and collects first-party audience data from TrendingVerse CMS.</p>

        <?php if ($refreshed): ?>
        <div class="notice notice-info is-dismissible"><p>Ad codes refreshed successfully.</p></div>
        <?php endif; ?>

        <?php if (!empty($key)): ?>
            <?php if ($status['connected']): ?>
            <div class="notice notice-success" style="padding:12px 16px;">
                <strong>&#10003; Connected</strong> &mdash; <?php echo esc_html($status['message']); ?>
            </div>
            <?php else: ?>
            <div class="notice notice-error" style="padding:12px 16px;">
                <strong>&#10007; Not connected</strong> &mdash; <?php echo esc_html($status['message']); ?>
            </div>
            <?php endif; ?>
        <?php endif; ?>

        <form method="post" action="options.php" style="margin-top:24px;">
            <?php settings_fields('tv_ads_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="tv_ads_publisher_key">Site Key</label></th>
                    <td>
                        <input type="text" id="tv_ads_publisher_key" name="tv_ads_publisher_key"
                            value="<?php echo esc_attr($key); ?>"
                            style="width:420px;font-family:monospace;font-size:13px;"
                            placeholder="e.g. a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4" />
                        <p class="description">
                            Get your Site Key from <a href="https://trendingverse-pages.pages.dev/admin/monetization/ad-units" target="_blank">
                            TrendingVerse CMS &rarr; Monetization &rarr; Ad Units</a> &mdash; click your site row to copy the key.
                        </p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_enabled">Enable Ads</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_enabled" name="tv_ads_enabled" value="1"
                                <?php checked($enabled, '1'); ?> />
                            Inject ads into all articles automatically
                        </label>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_tracking_enabled">Enable Audience Tracking</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_tracking_enabled" name="tv_ads_tracking_enabled" value="1"
                                <?php checked($tracking_enabled, '1'); ?> />
                            Collect anonymous first-party reader data (pageviews, location, device, scroll depth)
                        </label>
                        <p class="description">Enables lead capture popup and scroll depth tracking. Data sent to TrendingVerse CMS only.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_google_client_id">Google One Tap Client ID</label></th>
                    <td>
                        <input type="text" id="tv_ads_google_client_id" name="tv_ads_google_client_id"
                            value="<?php echo esc_attr($google_client_id); ?>"
                            style="width:420px;font-family:monospace;font-size:13px;"
                            placeholder="123456789-xxxx.apps.googleusercontent.com" />
                        <p class="description">
                            Optional. Get from <a href="https://console.cloud.google.com/apis/credentials" target="_blank">
                            Google Cloud Console &rarr; Credentials &rarr; OAuth 2.0 Client ID</a>.
                            Enables one-tap email capture &mdash; visitor clicks once using their Google account, no typing needed.
                        </p>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save & Connect'); ?>
        </form>

        <?php if ($status['connected'] && !empty($status['units'])): ?>
        <h2 style="margin-top:32px;">Active Ad Units (<?php echo count($status['units']); ?>)</h2>
        <table class="wp-list-table widefat fixed striped" style="max-width:700px;">
            <thead>
                <tr>
                    <th width="30">#</th>
                    <th>Placement</th>
                    <th>After Para</th>
                    <th>Size</th>
                    <th>Device</th>
                    <th>Type</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($status['units'] as $i => $unit): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><?php echo esc_html($unit['p'] ?? '—'); ?></td>
                    <td><?php echo ($unit['p'] === 'in_content') ? esc_html($unit['para'] ?? 2) : '—'; ?></td>
                    <td><?php echo esc_html(($unit['w'] ?? '') . 'x' . ($unit['h'] ?? '')); ?></td>
                    <td><?php echo esc_html($unit['dev'] ?? 'all'); ?></td>
                    <td>
                        <?php if (!empty($unit['directs'])): ?>
                            <code>DIRECT (<?php echo count($unit['directs']); ?>)</code>
                        <?php elseif (!empty($unit['net'])): ?>
                            <code>NETWORK</code>
                        <?php else: ?>
                            &mdash;
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p style="margin-top:16px;">
            <a href="<?php echo esc_url(admin_url('options-general.php?page=trendingverse-ads&refresh=1')); ?>"
                class="button button-secondary">&#8634; Refresh Ad Codes Now</a>
            <span style="color:#999;font-size:12px;margin-left:12px;">Auto-refreshes every hour</span>
        </p>
        <?php elseif ($status['connected']): ?>
        <div class="notice notice-warning" style="margin-top:24px;padding:12px 16px;">
            <p>&#10003; Connected &mdash; but no active ad units found. <a href="https://trendingverse-pages.pages.dev/admin/monetization/ad-units" target="_blank">Set up ad units &rarr;</a></p>
        </div>
        <?php endif; ?>
    </div>
    <?php
}

// ── CONNECTION TEST ───────────────────────────────────────────────

function tv_ads_test_connection($key) {
    if (empty($key)) return ['connected' => false, 'message' => 'No Site Key entered', 'units' => []];
    $data = tv_ads_fetch_config_raw($key);
    if (!$data) return ['connected' => false, 'message' => 'Connection failed — check your Site Key', 'units' => []];
    if (!$data['ok']) return ['connected' => false, 'message' => $data['error'] ?? 'Invalid Site Key', 'units' => []];
    if (!($data['enabled'] ?? true)) return ['connected' => true, 'message' => 'Site found but ads are currently disabled', 'units' => []];
    $units = $data['units'] ?? [];
    return ['connected' => true, 'message' => count($units) . ' ad unit(s) active for ' . get_site_url(), 'units' => $units];
}

// ── FETCH CONFIG (raw, no cache) ──────────────────────────────────

function tv_ads_fetch_config_raw($key) {
    if (empty($key)) return null;
    $response = wp_remote_get(TV_ADS_API . '?key=' . rawurlencode($key), [
        'timeout' => 15,
        'headers' => ['Accept' => 'application/json', 'User-Agent' => 'TrendingVerse-Ads/' . TV_ADS_VERSION],
    ]);
    if (is_wp_error($response)) return null;
    $code = wp_remote_retrieve_response_code($response);
    if ($code !== 200) return null;
    $data = json_decode(wp_remote_retrieve_body($response), true);
    return is_array($data) ? $data : null;
}

// ── FETCH CONFIG (with cache) ─────────────────────────────────────

function tv_ads_fetch_config($force = false) {
    $key = get_option('tv_ads_publisher_key', '');
    if (empty($key)) return null;

    if (!$force) {
        $cached = get_transient(TV_ADS_CACHE_KEY);
        if ($cached !== false) return $cached;
    }

    $data = tv_ads_fetch_config_raw($key);
    if ($data && !empty($data['ok'])) {
        set_transient(TV_ADS_CACHE_KEY, $data, TV_ADS_CACHE_TTL);
    }
    return $data;
}

add_action('admin_init', function () {
    if (isset($_GET['refresh']) && $_GET['refresh'] === '1' && current_user_can('manage_options')) {
        delete_transient(TV_ADS_CACHE_KEY);
        tv_ads_fetch_config(true);
        wp_redirect(admin_url('options-general.php?page=trendingverse-ads&refreshed=1'));
        exit;
    }
});

// ── AD INJECTION ──────────────────────────────────────────────────

add_filter('the_content', 'tv_ads_inject', 20);
function tv_ads_inject($content) {
    if (!is_single() || !is_main_query()) return $content;
    if (get_option('tv_ads_enabled', '1') !== '1') return $content;

    $config = tv_ads_fetch_config();
    if (empty($config) || !$config['ok'] || !($config['enabled'] ?? true)) return $content;

    $units = $config['units'] ?? [];
    if (empty($units)) return $content;

    $is_mobile   = wp_is_mobile();
    $header_html = '';
    $footer_html = '';
    $in_content  = [];

    foreach ($units as $unit) {
        // Device filter
        $dev = $unit['dev'] ?? 'all';
        if ($dev === 'mobile' && !$is_mobile) continue;
        if ($dev === 'desktop' && $is_mobile) continue;

        // Pick active HTML (direct campaign takes priority over network ad)
        $picked = tv_ads_pick_html($unit);
        if (empty($picked)) continue;

        $wrapped = tv_ads_wrap($picked['html'], $picked['mode'], intval($unit['w'] ?? 0), intval($unit['h'] ?? 0));
        if (empty(trim($wrapped))) continue;

        switch ($unit['p'] ?? '') {
            case 'header':
                $header_html .= $wrapped;
                break;
            case 'footer':
                $footer_html .= $wrapped;
                break;
            case 'in_content':
                $para = max(1, intval($unit['para'] ?? 2));
                $in_content[$para] = ($in_content[$para] ?? '') . $wrapped;
                break;
        }
    }

    if (!empty($in_content)) {
        $parts  = explode('</p>', $content);
        $result = [];
        foreach ($parts as $i => $part) {
            $result[] = $part;
            if ($i < count($parts) - 1) {
                $result[] = '</p>';
                if (isset($in_content[$i + 1])) $result[] = $in_content[$i + 1];
            }
        }
        $content = implode('', $result);
    }

    return $header_html . $content . $footer_html;
}

/**
 * Pick the best HTML to display for a unit.
 * Direct campaigns (time-windowed) take priority over the network ad.
 * Returns ['html' => string, 'mode' => 'inline'|'iframe'] or null.
 */
function tv_ads_pick_html($unit) {
    $now_ms  = round(microtime(true) * 1000);
    $directs = $unit['directs'] ?? [];

    foreach ($directs as $d) {
        $html = trim($d['html'] ?? '');
        if (empty($html)) continue;
        $start = intval($d['s'] ?? 0);
        $end   = intval($d['e'] ?? 0);
        if ($start > 0 && $now_ms < $start) continue;
        if ($end > 0 && $now_ms > $end) continue;
        return ['html' => $html, 'mode' => $d['mode'] ?? 'inline'];
    }

    // Fall back to network ad
    $net = $unit['net'] ?? null;
    if ($net && !empty(trim($net['html'] ?? ''))) {
        return ['html' => $net['html'], 'mode' => $net['mode'] ?? 'inline'];
    }

    return null;
}

/**
 * Wrap ad HTML in a container div.
 * Uses iframe srcdoc for scripts that use document.write (mode=iframe).
 */
function tv_ads_wrap($html, $mode, $w, $h) {
    $style = 'text-align:center;margin:20px auto;clear:both;line-height:0;';
    if ($w > 0) $style .= "max-width:{$w}px;";

    if ($mode === 'iframe') {
        $encoded = htmlspecialchars($html, ENT_QUOTES, 'UTF-8');
        $iw = $w > 0 ? $w : 300;
        $ih = $h > 0 ? $h : 250;
        return sprintf(
            '<div style="%s"><iframe srcdoc="%s" width="%d" height="%d" frameborder="0" scrolling="no" style="border:0;overflow:hidden;display:block;margin:auto;" loading="lazy"></iframe></div>' . "\n",
            esc_attr($style), $encoded, $iw, $ih
        );
    }

    return sprintf('<div style="%s">%s</div>' . "\n", esc_attr($style), $html);
}

// ── AUDIENCE TRACKING ─────────────────────────────────────────────

add_action('wp_head', 'tv_ads_inject_tracker', 5);
function tv_ads_inject_tracker() {
    $key              = get_option('tv_ads_publisher_key', '');
    $tracking_enabled = get_option('tv_ads_tracking_enabled', '1');
    $google_client_id = get_option('tv_ads_google_client_id', '');

    if (empty($key) || $tracking_enabled !== '1') return;

    $category = '';
    if (is_single()) {
        $cats = get_the_category();
        if (!empty($cats)) $category = esc_js($cats[0]->name);
    }

    echo '<script>';
    echo 'window.TV_SITE_URL = "' . esc_js(get_site_url()) . '";';
    echo 'window.TV_CATEGORY = "' . $category . '";';
    if (!empty($google_client_id)) {
        echo 'window.TV_GOOGLE_CLIENT_ID = "' . esc_js($google_client_id) . '";';
    }
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        if (!empty($current_user->user_email)) {
            echo 'window.TV_USER_EMAIL = "' . esc_js($current_user->user_email) . '";';
        }
    }
    echo '</script>' . "\n";
    echo '<script src="https://trendingverse-pages.pages.dev/tv-tracker.js" async defer></script>' . "\n";
}

// ── SCHEDULED TASKS ───────────────────────────────────────────────

register_activation_hook(__FILE__, function () {
    if (!wp_next_scheduled('tv_ads_hourly_refresh'))
        wp_schedule_event(time(), 'hourly', 'tv_ads_hourly_refresh');
});

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('tv_ads_hourly_refresh');
    delete_transient(TV_ADS_CACHE_KEY);
});

add_action('tv_ads_hourly_refresh', function () {
    tv_ads_fetch_config(true);
});
