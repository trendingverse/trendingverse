<?php
/**
 * Plugin Name: TrendingVerse Ads
 * Plugin URI: https://trendingverse.vercel.app
 * Description: Automatically fetches and injects monetization ads from TrendingVerse CMS. Includes audience tracking for first-party data collection.
 * Version: 1.0.3
 * Author: TrendingVerse
 * Author URI: https://trendingverse.vercel.app
 * License: GPL2
 */

if (!defined('ABSPATH')) exit;

define('TV_ADS_VERSION',    '1.0.3');
define('TV_ADS_API',        'https://trendingverse.vercel.app/api/admin/publishers/ad-codes');
define('TV_ADS_UPDATE_URL', 'https://trendingverse.vercel.app/api/plugin/update-check');
define('TV_ADS_DOWNLOAD',   'https://trendingverse.vercel.app/api/plugin/download');
define('TV_TRACKER_URL',    'https://trendingverse.vercel.app/api/audience/track');
define('TV_ADS_CACHE_KEY',  'tv_ads_cache');
define('TV_ADS_CACHE_TTL',  3600);

// ── AUTO-UPDATE MECHANISM ────────────────────────────────────────

add_filter('pre_set_site_transient_update_plugins', 'tv_ads_check_update');
function tv_ads_check_update($transient) {
    if (empty($transient->checked)) return $transient;

    $response = wp_remote_get(TV_ADS_UPDATE_URL, [
        'timeout' => 10,
        'headers' => ['Accept' => 'application/json'],
    ]);

    if (is_wp_error($response)) return $transient;

    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($data['version'])) return $transient;

    if (version_compare(TV_ADS_VERSION, $data['version'], '<')) {
        $transient->response['trendingverse-ads/trendingverse-ads.php'] = (object) [
            'slug'        => 'trendingverse-ads',
            'plugin'      => 'trendingverse-ads/trendingverse-ads.php',
            'new_version' => $data['version'],
            'url'         => 'https://trendingverse.vercel.app',
            'package'     => TV_ADS_DOWNLOAD,
        ];
    }

    return $transient;
}

add_filter('plugins_api', 'tv_ads_plugin_info', 20, 3);
function tv_ads_plugin_info($result, $action, $args) {
    if ($action !== 'plugin_information') return $result;
    if (!isset($args->slug) || $args->slug !== 'trendingverse-ads') return $result;

    $response = wp_remote_get(TV_ADS_UPDATE_URL . '?action=info', [
        'timeout' => 10,
        'headers' => ['Accept' => 'application/json'],
    ]);

    if (is_wp_error($response)) return $result;

    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($data)) return $result;

    return (object) [
        'name'          => $data['name']         ?? 'TrendingVerse Ads',
        'slug'          => 'trendingverse-ads',
        'version'       => $data['version']      ?? TV_ADS_VERSION,
        'author'        => $data['author']        ?? 'TrendingVerse',
        'last_updated'  => $data['last_updated']  ?? '',
        'requires'      => $data['requires']      ?? '5.0',
        'tested'        => $data['tested']        ?? '6.5',
        'download_link' => TV_ADS_DOWNLOAD,
        'sections'      => $data['sections']      ?? [],
    ];
}

// ── ADMIN SETTINGS PAGE ──────────────────────────────────────────

add_action('admin_menu', function () {
    add_options_page('TrendingVerse Ads', 'TrendingVerse Ads', 'manage_options', 'trendingverse-ads', 'tv_ads_settings_page');
});

add_action('admin_init', function () {
    register_setting('tv_ads_settings', 'tv_ads_publisher_key');
    register_setting('tv_ads_settings', 'tv_ads_enabled');
    register_setting('tv_ads_settings', 'tv_ads_tracking_enabled');
});

function tv_ads_settings_page() {
    $key              = get_option('tv_ads_publisher_key', '');
    $enabled          = get_option('tv_ads_enabled', '1');
    $tracking_enabled = get_option('tv_ads_tracking_enabled', '1');
    $status           = tv_ads_test_connection($key);
    $refreshed        = isset($_GET['refreshed']);
    ?>
    <div class="wrap">
        <h1>🎯 TrendingVerse Ads
            <span style="font-size:12px;background:#111;color:#fff;padding:2px 8px;border-radius:20px;font-weight:400;">v<?php echo TV_ADS_VERSION; ?></span>
        </h1>
        <p style="color:#666;">Automatically injects monetization ads and collects first-party audience data from TrendingVerse CMS.</p>

        <?php if ($refreshed): ?>
        <div class="notice notice-info is-dismissible"><p>Ad codes refreshed successfully.</p></div>
        <?php endif; ?>

        <?php if (!empty($key)): ?>
            <?php if ($status['connected']): ?>
            <div class="notice notice-success" style="padding:12px 16px;">
                <strong>✓ Connected</strong> — <?php echo esc_html($status['message']); ?>
            </div>
            <?php else: ?>
            <div class="notice notice-error" style="padding:12px 16px;">
                <strong>✗ Not connected</strong> — <?php echo esc_html($status['message']); ?>
            </div>
            <?php endif; ?>
        <?php endif; ?>

        <form method="post" action="options.php" style="margin-top:24px;">
            <?php settings_fields('tv_ads_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="tv_ads_publisher_key">Publisher API Key</label></th>
                    <td>
                        <input type="text" id="tv_ads_publisher_key" name="tv_ads_publisher_key"
                            value="<?php echo esc_attr($key); ?>"
                            style="width:420px;font-family:monospace;font-size:13px;"
                            placeholder="tvp_xxxxxxxxxxxxxxxxxxxxxxxx" />
                        <p class="description">
                            Get your key from <a href="https://trendingverse.vercel.app/admin/settings" target="_blank">
                            TrendingVerse CMS → Settings → API Keys</a>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_enabled">Enable Ads</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_enabled" name="tv_ads_enabled" value="1"
                                <?php checked($enabled, '1'); ?> />
                            Inject ads into all articles automatically
                        </label>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_tracking_enabled">Enable Audience Tracking</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_tracking_enabled" name="tv_ads_tracking_enabled" value="1"
                                <?php checked($tracking_enabled, '1'); ?> />
                            Collect anonymous first-party reader data (pageviews, location, device, interests)
                        </label>
                        <p class="description">Enables lead capture popup after 30 seconds. Data sent to TrendingVerse CMS only.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save & Connect'); ?>
        </form>

        <?php if ($status['connected'] && !empty($status['ads'])): ?>
        <h2 style="margin-top:32px;">Active Ad Slots (<?php echo count($status['ads']); ?>)</h2>
        <table class="wp-list-table widefat fixed striped" style="max-width:600px;">
            <thead>
                <tr>
                    <th width="40">#</th>
                    <th>Position</th>
                    <th>After Paragraph</th>
                    <th>Size</th>
                    <th>Type</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($status['ads'] as $i => $ad): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><?php echo esc_html($ad['position'] ?? '—'); ?></td>
                    <td><?php echo ($ad['position'] === 'in_content') ? esc_html($ad['inject_after_paragraph'] ?? 2) : '—'; ?></td>
                    <td><?php echo esc_html(($ad['size_width'] ?? '') . 'x' . ($ad['size_height'] ?? '')); ?></td>
                    <td><code><?php echo esc_html(strtoupper($ad['ad_type'] ?? '')); ?></code></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p style="margin-top:16px;">
            <a href="<?php echo esc_url(admin_url('options-general.php?page=trendingverse-ads&refresh=1')); ?>"
                class="button button-secondary">↺ Refresh Ad Codes Now</a>
            <span style="color:#999;font-size:12px;margin-left:12px;">Auto-refreshes every hour</span>
        </p>
        <?php endif; ?>
    </div>
    <?php
}

// ── CONNECTION TEST ───────────────────────────────────────────────

function tv_ads_test_connection($key) {
    if (empty($key)) return ['connected' => false, 'message' => 'No API key entered', 'ads' => []];
    $ads = tv_ads_fetch_codes($key, true);
    if (is_wp_error($ads)) return ['connected' => false, 'message' => $ads->get_error_message(), 'ads' => []];
    return ['connected' => true, 'message' => count($ads) . ' ad slot(s) active for ' . get_site_url(), 'ads' => $ads];
}

// ── FETCH AD CODES ────────────────────────────────────────────────

function tv_ads_fetch_codes($key = null, $force = false) {
    if (!$key) $key = get_option('tv_ads_publisher_key', '');
    if (empty($key)) return [];

    if (!$force) {
        $cached = get_transient(TV_ADS_CACHE_KEY);
        if ($cached !== false) return $cached;
    }

    $response = wp_remote_get(add_query_arg(['key' => $key, 'site' => get_site_url()], TV_ADS_API), [
        'timeout' => 15,
        'headers' => ['Accept' => 'application/json', 'User-Agent' => 'TrendingVerse-Ads/' . TV_ADS_VERSION],
    ]);

    if (is_wp_error($response)) return new WP_Error('api_error', 'Connection failed: ' . $response->get_error_message());

    $code = wp_remote_retrieve_response_code($response);
    $data = json_decode(wp_remote_retrieve_body($response), true);

    if ($code === 401) return new WP_Error('api_error', 'Invalid API key');
    if ($code !== 200) return new WP_Error('api_error', 'API returned status ' . $code);
    if (!isset($data['ads'])) return new WP_Error('api_error', 'Unexpected API response');

    set_transient(TV_ADS_CACHE_KEY, $data['ads'], TV_ADS_CACHE_TTL);
    return $data['ads'];
}

add_action('admin_init', function () {
    if (isset($_GET['refresh']) && $_GET['refresh'] === '1' && current_user_can('manage_options')) {
        delete_transient(TV_ADS_CACHE_KEY);
        tv_ads_fetch_codes(null, true);
        wp_redirect(admin_url('options-general.php?page=trendingverse-ads&refreshed=1'));
        exit;
    }
});

// ── AD INJECTION ──────────────────────────────────────────────────

add_filter('the_content', 'tv_ads_inject', 20);
function tv_ads_inject($content) {
    if (!is_single() || !is_main_query()) return $content;
    if (get_option('tv_ads_enabled', '1') !== '1') return $content;

    $ads = tv_ads_fetch_codes();
    if (empty($ads) || is_wp_error($ads)) return $content;

    $header_ads = $footer_ads = '';
    $in_content = [];

    foreach ($ads as $ad) {
        if (empty($ad['is_enabled'])) continue;
        $html = tv_ads_build_html($ad);
        if (empty(trim($html))) continue;
        switch ($ad['position'] ?? '') {
            case 'header':     $header_ads .= $html; break;
            case 'footer':     $footer_ads .= $html; break;
            case 'in_content':
                $para = max(1, intval($ad['inject_after_paragraph'] ?? 2));
                $in_content[$para] = ($in_content[$para] ?? '') . $html;
                break;
        }
    }

    if (!empty($in_content)) {
        $parts  = explode('</p>', $content);
        $result = [];
        foreach ($parts as $i => $part) {
            $result[] = $part;
            if ($i < count($parts) - 1) {
                $result[] = '</p>';
                if (isset($in_content[$i + 1])) $result[] = $in_content[$i + 1];
            }
        }
        $content = implode('', $result);
    }

    return $header_ads . $content . $footer_ads;
}

function tv_ads_build_html($ad) {
    $wrap = 'text-align:center;margin:20px auto;clear:both;line-height:0;';

    // Block restricted categories
    $blocked = ['casino', 'gambling', 'bet', 'poker', 'slots', 'lottery', 'adult', 'xxx', 'porn', 'one-vv5163.com'];
    $code_lower = strtolower($ad['ad_code'] ?? '');
    foreach ($blocked as $kw) {
        if (strpos($code_lower, $kw) !== false) return '';
    }

    if (($ad['ad_type'] ?? '') === 'gam' && !empty($ad['gam_unit_path'])) {
        $div_id = 'tv-ad-' . substr(md5(($ad['id'] ?? '') . time()), 0, 12);
        return sprintf(
            '<div id="%s" style="%s"><script>window.googletag=window.googletag||{cmd:[]};googletag.cmd.push(function(){googletag.defineSlot("%s",[%d,%d],"%s").addService(googletag.pubads());googletag.pubads().enableSingleRequest();googletag.enableServices();googletag.display("%s");});</script></div>' . "\n",
            esc_attr($div_id), esc_attr($wrap),
            esc_js($ad['gam_unit_path']),
            intval($ad['size_width'] ?? 300), intval($ad['size_height'] ?? 250),
            esc_attr($div_id), esc_attr($div_id)
        );
    }

    if (!empty($ad['ad_code'])) {
        return sprintf('<div style="%s">%s</div>' . "\n", esc_attr($wrap), $ad['ad_code']);
    }

    return '';
}

add_action('wp_head', function () {
    if (get_option('tv_ads_enabled', '1') !== '1') return;
    $ads = tv_ads_fetch_codes();
    if (empty($ads) || is_wp_error($ads)) return;
    foreach ($ads as $ad) {
        if (($ad['ad_type'] ?? '') === 'gam' && !empty($ad['gam_network_code'])) {
            echo '<script async src="https://securepubads.g.doubleclick.net/tag/js/gpt.js"></script>' . "\n";
            break;
        }
    }
}, 1);

// ── AUDIENCE TRACKING ─────────────────────────────────────────────

add_action('wp_head', 'tv_ads_inject_tracker', 5);
function tv_ads_inject_tracker() {
    $key              = get_option('tv_ads_publisher_key', '');
    $tracking_enabled = get_option('tv_ads_tracking_enabled', '1');

    if (empty($key) || $tracking_enabled !== '1') return;

    $category = '';
    if (is_single()) {
        $cats = get_the_category();
        if (!empty($cats)) $category = esc_js($cats[0]->name);
    }

    $site_url = esc_js(get_site_url());

    echo '<script>';
    echo 'window.TV_SITE_URL = "' . $site_url . '";';
    echo 'window.TV_CATEGORY = "' . $category . '";';
    echo '</script>';
    echo '<script src="https://trendingverse.vercel.app/tv-tracker.js" async defer></script>' . "\n";
}

// ── SCHEDULED TASKS ───────────────────────────────────────────────

register_activation_hook(__FILE__, function () {
    if (!wp_next_scheduled('tv_ads_hourly_refresh'))
        wp_schedule_event(time(), 'hourly', 'tv_ads_hourly_refresh');
});

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('tv_ads_hourly_refresh');
    delete_transient(TV_ADS_CACHE_KEY);
});

add_action('tv_ads_hourly_refresh', function () {
    tv_ads_fetch_codes(null, true);
});
