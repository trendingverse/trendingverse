<?php
/**
 * Plugin Name: TrendingVerse Ads
 * Plugin URI: https://trendingverse-pages.pages.dev
 * Description: Automatically fetches and injects monetization ads from TrendingVerse CMS. Includes audience tracking, structured data (JSON-LD), ads.txt serving, and related articles.
 * Version: 2.0.0
 * Author: TrendingVerse
 * Author URI: https://trendingverse-pages.pages.dev
 * License: GPL2
 */

if (!defined('ABSPATH')) exit;

define('TV_ADS_VERSION',    '2.0.0');
define('TV_ADS_API',        'https://trendingverse-pages.pages.dev/api/admin/publishers/ad-codes');
define('TV_ADS_UPDATE_URL', 'https://trendingverse-pages.pages.dev/api/plugin/update-check');
define('TV_ADS_DOWNLOAD',   'https://trendingverse-pages.pages.dev/api/plugin/download');
define('TV_ADS_ADSTXT_API', 'https://trendingverse-pages.pages.dev/api/monetization/ads-txt');
define('TV_ADS_CACHE_KEY',  'tv_ads_cache');
define('TV_ADS_CACHE_TTL',  3600);

// ── AUTO-UPDATE ──────────────────────────────────────────────────

add_filter('pre_set_site_transient_update_plugins', 'tv_ads_check_update');
function tv_ads_check_update($transient) {
    if (empty($transient->checked)) return $transient;
    $response = wp_remote_get(TV_ADS_UPDATE_URL, ['timeout' => 10, 'headers' => ['Accept' => 'application/json']]);
    if (is_wp_error($response)) return $transient;
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($data['version'])) return $transient;
    if (version_compare(TV_ADS_VERSION, $data['version'], '<')) {
        $transient->response['trendingverse-ads/trendingverse-ads.php'] = (object) [
            'slug'        => 'trendingverse-ads',
            'plugin'      => 'trendingverse-ads/trendingverse-ads.php',
            'new_version' => $data['version'],
            'url'         => 'https://trendingverse-pages.pages.dev',
            'package'     => TV_ADS_DOWNLOAD,
        ];
    }
    return $transient;
}

add_filter('plugins_api', 'tv_ads_plugin_info', 20, 3);
function tv_ads_plugin_info($result, $action, $args) {
    if ($action !== 'plugin_information') return $result;
    if (!isset($args->slug) || $args->slug !== 'trendingverse-ads') return $result;
    $response = wp_remote_get(TV_ADS_UPDATE_URL . '?action=info', ['timeout' => 10, 'headers' => ['Accept' => 'application/json']]);
    if (is_wp_error($response)) return $result;
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($data)) return $result;
    return (object) [
        'name'          => $data['name']         ?? 'TrendingVerse Ads',
        'slug'          => 'trendingverse-ads',
        'version'       => $data['version']      ?? TV_ADS_VERSION,
        'author'        => $data['author']        ?? 'TrendingVerse',
        'last_updated'  => $data['last_updated']  ?? '',
        'requires'      => $data['requires']      ?? '5.0',
        'tested'        => $data['tested']        ?? '6.5',
        'download_link' => TV_ADS_DOWNLOAD,
        'sections'      => $data['sections']      ?? [],
    ];
}

// ── ADMIN SETTINGS ───────────────────────────────────────────────

add_action('admin_menu', function () {
    add_options_page('TrendingVerse Ads', 'TrendingVerse Ads', 'manage_options', 'trendingverse-ads', 'tv_ads_settings_page');
});

add_action('admin_init', function () {
    register_setting('tv_ads_settings', 'tv_ads_publisher_key');
    register_setting('tv_ads_settings', 'tv_ads_enabled');
    register_setting('tv_ads_settings', 'tv_ads_tracking_enabled');
    register_setting('tv_ads_settings', 'tv_ads_google_client_id');
    register_setting('tv_ads_settings', 'tv_ads_structured_data');
    register_setting('tv_ads_settings', 'tv_ads_related_posts');
    register_setting('tv_ads_settings', 'tv_ads_adsense_publisher_id');
});

function tv_ads_settings_page() {
    $key              = get_option('tv_ads_publisher_key', '');
    $enabled          = get_option('tv_ads_enabled', '1');
    $tracking_enabled = get_option('tv_ads_tracking_enabled', '1');
    $google_client_id = get_option('tv_ads_google_client_id', '');
    $structured_data  = get_option('tv_ads_structured_data', '1');
    $related_posts    = get_option('tv_ads_related_posts', '1');
    $adsense_pub      = get_option('tv_ads_adsense_publisher_id', '');
    $status           = tv_ads_test_connection($key);
    $refreshed        = isset($_GET['refreshed']);
    ?>
    <div class="wrap">
        <h1>🎯 TrendingVerse Ads
            <span style="font-size:12px;background:#111;color:#fff;padding:2px 8px;border-radius:20px;font-weight:400;">v<?php echo TV_ADS_VERSION; ?></span>
        </h1>
        <p style="color:#666;">Automatically injects monetization ads, structured data, and audience tracking from TrendingVerse CMS.</p>

        <?php if ($refreshed): ?>
        <div class="notice notice-info is-dismissible"><p>Ad codes refreshed successfully.</p></div>
        <?php endif; ?>

        <?php if (!empty($key)): ?>
            <?php if ($status['connected']): ?>
            <div class="notice notice-success" style="padding:12px 16px;">
                <strong>✓ Connected</strong> — <?php echo esc_html($status['message']); ?>
            </div>
            <?php else: ?>
            <div class="notice notice-error" style="padding:12px 16px;">
                <strong>✗ Not connected</strong> — <?php echo esc_html($status['message']); ?>
            </div>
            <?php endif; ?>
        <?php endif; ?>

        <!-- ads.txt status -->
        <div class="notice notice-info" style="padding:12px 16px;margin-top:16px;">
            <strong>📋 ads.txt:</strong> Served automatically at
            <a href="<?php echo esc_url(get_site_url() . '/ads.txt'); ?>" target="_blank"><?php echo esc_html(get_site_url()); ?>/ads.txt</a>
            — entries managed in TrendingVerse CMS → Monetization → ads.txt.
            <?php if (!empty($adsense_pub)): ?>
            <span style="color:green;margin-left:8px;">✓ AdSense pub ID saved</span>
            <?php else: ?>
            <span style="color:#c00;margin-left:8px;">⚠ Enter your AdSense Publisher ID below</span>
            <?php endif; ?>
        </div>

        <form method="post" action="options.php" style="margin-top:24px;">
            <?php settings_fields('tv_ads_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="tv_ads_publisher_key">Publisher API Key</label></th>
                    <td>
                        <input type="text" id="tv_ads_publisher_key" name="tv_ads_publisher_key"
                            value="<?php echo esc_attr($key); ?>"
                            style="width:420px;font-family:monospace;font-size:13px;"
                            placeholder="tvp_xxxxxxxxxxxxxxxxxxxxxxxx" />
                        <p class="description">
                            Get your key from <a href="https://trendingverse-pages.pages.dev/admin/settings" target="_blank">
                            TrendingVerse CMS → Settings → API Keys</a>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_adsense_publisher_id">Google AdSense Publisher ID</label></th>
                    <td>
                        <input type="text" id="tv_ads_adsense_publisher_id" name="tv_ads_adsense_publisher_id"
                            value="<?php echo esc_attr($adsense_pub); ?>"
                            style="width:280px;font-family:monospace;font-size:13px;"
                            placeholder="pub-1234567890123456" />
                        <p class="description">
                            Find in <a href="https://www.google.com/adsense/new/u/0/pub-XXXX/home" target="_blank">AdSense → Account → Account information</a>.
                            Format: <code>pub-XXXXXXXXXXXXXXXX</code> (16 digits).
                            This is added to ads.txt automatically.
                        </p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_enabled">Enable Ads</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_enabled" name="tv_ads_enabled" value="1"
                                <?php checked($enabled, '1'); ?> />
                            Inject ads into all articles automatically
                        </label>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_structured_data">Structured Data (JSON-LD)</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_structured_data" name="tv_ads_structured_data" value="1"
                                <?php checked($structured_data, '1'); ?> />
                            Add Article, WebSite, and Organization schema markup to pages
                        </label>
                        <p class="description">Helps Google understand your content — required for rich results and improves organic rankings. Strongly recommended.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_related_posts">Related Articles</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_related_posts" name="tv_ads_related_posts" value="1"
                                <?php checked($related_posts, '1'); ?> />
                            Show 4 related articles at the bottom of each post
                        </label>
                        <p class="description">Improves internal linking (which affects SEO rankings) and reduces bounce rate.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_tracking_enabled">Audience Tracking</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_tracking_enabled" name="tv_ads_tracking_enabled" value="1"
                                <?php checked($tracking_enabled, '1'); ?> />
                            Collect anonymous first-party reader data (pageviews, location, device, scroll depth)
                        </label>
                        <p class="description">Enables lead capture popup and scroll depth tracking. Data sent to TrendingVerse CMS only.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_google_client_id">Google One Tap Client ID</label></th>
                    <td>
                        <input type="text" id="tv_ads_google_client_id" name="tv_ads_google_client_id"
                            value="<?php echo esc_attr($google_client_id); ?>"
                            style="width:420px;font-family:monospace;font-size:13px;"
                            placeholder="123456789-xxxx.apps.googleusercontent.com" />
                        <p class="description">
                            Optional. Get from <a href="https://console.cloud.google.com/apis/credentials" target="_blank">
                            Google Cloud Console → Credentials → OAuth 2.0 Client ID</a>.
                        </p>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save Settings'); ?>
        </form>

        <?php if ($status['connected'] && !empty($status['ads'])): ?>
        <h2 style="margin-top:32px;">Active Ad Slots (<?php echo count($status['ads']); ?>)</h2>
        <table class="wp-list-table widefat fixed striped" style="max-width:600px;">
            <thead>
                <tr>
                    <th width="40">#</th>
                    <th>Position</th>
                    <th>After Paragraph</th>
                    <th>Size</th>
                    <th>Type</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($status['ads'] as $i => $ad): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><?php echo esc_html($ad['position'] ?? '—'); ?></td>
                    <td><?php echo ($ad['position'] === 'in_content') ? esc_html($ad['inject_after_paragraph'] ?? 2) : '—'; ?></td>
                    <td><?php echo esc_html(($ad['size_width'] ?? '') . 'x' . ($ad['size_height'] ?? '')); ?></td>
                    <td><code><?php echo esc_html(strtoupper($ad['ad_type'] ?? '')); ?></code></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p style="margin-top:16px;">
            <a href="<?php echo esc_url(admin_url('options-general.php?page=trendingverse-ads&refresh=1')); ?>"
                class="button button-secondary">↺ Refresh Ad Codes Now</a>
            <span style="color:#999;font-size:12px;margin-left:12px;">Auto-refreshes every hour</span>
        </p>
        <?php endif; ?>

        <!-- AdSense Readiness Checklist -->
        <h2 style="margin-top:40px;">📋 AdSense Readiness Checklist</h2>
        <?php tv_ads_adsense_checklist(); ?>
    </div>
    <?php
}

function tv_ads_adsense_checklist() {
    $checks = [];

    // Privacy Policy
    $pp = get_page_by_path('privacy-policy');
    $checks[] = ['label' => 'Privacy Policy page exists', 'pass' => !empty($pp), 'fix' => 'Create a page at /privacy-policy/ covering data collection, cookies, and third-party ads.'];

    // About Us
    $about = get_page_by_path('about-us') ?: get_page_by_path('about');
    $checks[] = ['label' => 'About Us page exists', 'pass' => !empty($about), 'fix' => 'Create an About page describing your site, team, and editorial process.'];

    // Contact
    $contact = get_page_by_path('contact') ?: get_page_by_path('contact-us');
    $checks[] = ['label' => 'Contact page exists', 'pass' => !empty($contact), 'fix' => 'Create a Contact page with a form or email address.'];

    // AdSense pub ID
    $pub = get_option('tv_ads_adsense_publisher_id', '');
    $checks[] = ['label' => 'AdSense Publisher ID entered', 'pass' => !empty($pub) && strpos($pub, 'pub-') === 0, 'fix' => 'Enter your pub-XXXXXXXX ID in the field above so it appears in ads.txt.'];

    // Structured data
    $sd = get_option('tv_ads_structured_data', '1');
    $checks[] = ['label' => 'Article structured data (JSON-LD) enabled', 'pass' => $sd === '1', 'fix' => 'Enable Structured Data above to add Article schema to all posts.'];

    // Post count
    $post_count = wp_count_posts()->publish;
    $checks[] = ['label' => "Published posts ($post_count — Google wants 20+)", 'pass' => $post_count >= 20, 'fix' => 'Publish more original articles before applying for AdSense.'];

    // Sitemap
    $sitemap_url = get_site_url() . '/sitemap.xml';
    $checks[] = ['label' => 'Sitemap exists (/sitemap.xml)', 'pass' => true, 'fix' => ''];  // Jetpack handles this

    // ads.txt
    $checks[] = ['label' => 'ads.txt served by plugin', 'pass' => true, 'fix' => ''];  // This plugin handles it

    echo '<table class="wp-list-table widefat" style="max-width:700px;margin-top:12px;">';
    echo '<thead><tr><th>Check</th><th width="80">Status</th><th>Action</th></tr></thead><tbody>';
    foreach ($checks as $c) {
        $icon = $c['pass'] ? '<span style="color:green;font-size:16px;">✓</span>' : '<span style="color:#c00;font-size:16px;">✗</span>';
        $fix  = $c['pass'] ? '' : '<span style="color:#666;font-size:12px;">' . esc_html($c['fix']) . '</span>';
        echo "<tr><td>{$c['label']}</td><td style='text-align:center;'>{$icon}</td><td>{$fix}</td></tr>";
    }
    echo '</tbody></table>';
}

// ── ads.txt SERVING ───────────────────────────────────────────────

add_action('parse_request', 'tv_ads_serve_adstxt');
function tv_ads_serve_adstxt($wp) {
    // Only intercept exact /ads.txt request
    $request = trim($wp->request, '/');
    if ($request !== 'ads.txt' && $_SERVER['REQUEST_URI'] !== '/ads.txt') return;

    // Build ads.txt content
    $lines = [];

    // Header
    $lines[] = '# ads.txt — TrendingVerse Publisher Network';
    $lines[] = '# Generated by TrendingVerse Ads Plugin v' . TV_ADS_VERSION;
    $lines[] = '# Last updated: ' . date('Y-m-d H:i:s T');
    $lines[] = '';

    // Publisher contact
    $admin_email = get_option('admin_email', '');
    if ($admin_email) $lines[] = 'CONTACT=' . $admin_email;
    $lines[] = 'OWNERDOMAIN=' . parse_url(get_site_url(), PHP_URL_HOST);
    $lines[] = '';

    // Google AdSense (from local option — always first)
    $pub = get_option('tv_ads_adsense_publisher_id', '');
    if (!empty($pub) && strpos($pub, 'pub-') === 0) {
        $lines[] = '# Google AdSense';
        $lines[] = "google.com, {$pub}, DIRECT, f08c47fec0942fa0";
        $lines[] = '';
    }

    // Fetch entries from TrendingVerse CMS
    $key = get_option('tv_ads_publisher_key', '');
    if (!empty($key)) {
        $cached = get_transient('tv_adstxt_cache');
        if ($cached === false) {
            $res = wp_remote_get(add_query_arg([
                'key'      => $key,
                'site_url' => get_site_url(),
            ], TV_ADS_ADSTXT_API), [
                'timeout' => 10,
                'headers' => ['Accept' => 'application/json'],
            ]);
            if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200) {
                $data = json_decode(wp_remote_retrieve_body($res), true);
                $cached = $data['entries'] ?? [];
                set_transient('tv_adstxt_cache', $cached, 3600);
            } else {
                $cached = [];
            }
        }

        if (!empty($cached)) {
            $lines[] = '# TrendingVerse Network Partners';
            foreach ($cached as $entry) {
                if (empty($entry['is_active'])) continue;
                $line = $entry['ad_system'] . ', ' . $entry['publisher_id'] . ', ' . $entry['relationship'];
                if (!empty($entry['cert_authority_id'])) $line .= ', ' . $entry['cert_authority_id'];
                $lines[] = $line;
            }
        }
    }

    // Fallback: common known network entries if no CMS entries found
    // These are standard reseller entries that all publishers should include
    $fallback_entries = [
        '# Standard SSP/Exchange entries (resellers)',
        'rubiconproject.com, 23644, RESELLER, 0bfd66d529a55807',
        'openx.com, 540191398, RESELLER, 6a698e965929, openx.com',
        'pubmatic.com, 158060, RESELLER, 5d62403b186f2ace',
        'appnexus.com, 7944, RESELLER, f5ab79cb980f11d1',
        'indexexchange.com, 191000, RESELLER',
        'triplelift.com, 11392, RESELLER, 6c33edb13117fd86',
    ];
    // Only add fallback if we got no CMS entries
    if (empty($cached)) {
        $lines[] = '';
        foreach ($fallback_entries as $e) $lines[] = $e;
    }

    $output = implode("\n", $lines) . "\n";

    header('Content-Type: text/plain; charset=UTF-8');
    header('Cache-Control: public, max-age=3600');
    header('X-Robots-Tag: noindex');
    echo $output;
    exit;
}

// ── STRUCTURED DATA (JSON-LD) ─────────────────────────────────────

add_action('wp_head', 'tv_ads_structured_data', 2);
function tv_ads_structured_data() {
    // Skip if Rank Math or Yoast SEO is active — they already output structured data
    if (defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION')) return;
    if (get_option('tv_ads_structured_data', '1') !== '1') return;

    $site_name = get_bloginfo('name');
    $site_url  = get_site_url();
    $logo_url  = get_site_icon_url(512) ?: '';

    // WebSite schema — on every page
    $website = [
        '@context' => 'https://schema.org',
        '@type'    => 'WebSite',
        'name'     => $site_name,
        'url'      => $site_url,
        'potentialAction' => [
            '@type'       => 'SearchAction',
            'target'      => [
                '@type'       => 'EntryPoint',
                'urlTemplate' => $site_url . '/?s={search_term_string}',
            ],
            'query-input' => 'required name=search_term_string',
        ],
    ];

    // Organization schema — on every page
    $org = [
        '@context' => 'https://schema.org',
        '@type'    => 'NewsMediaOrganization',
        'name'     => $site_name,
        'url'      => $site_url,
        'sameAs'   => [],
    ];
    if ($logo_url) {
        $org['logo'] = [
            '@type' => 'ImageObject',
            'url'   => $logo_url,
        ];
    }

    // Article schema — on single posts only
    if (is_single()) {
        global $post;
        setup_postdata($post);

        $author_name  = get_the_author_meta('display_name', $post->post_author);
        $author_url   = get_author_posts_url($post->post_author);
        $published    = get_the_date('c', $post);
        $modified     = get_the_modified_date('c', $post);
        $permalink    = get_permalink($post);
        $title        = get_the_title($post);
        $excerpt      = wp_strip_all_tags(get_the_excerpt($post));
        $thumb_url    = get_the_post_thumbnail_url($post, 'large') ?: $logo_url;

        $categories   = get_the_category($post->ID);
        $sections     = array_map(function($c) { return $c->name; }, $categories);

        $article = [
            '@context'         => 'https://schema.org',
            '@type'            => 'NewsArticle',
            'headline'         => substr($title, 0, 110),
            'description'      => substr($excerpt, 0, 200),
            'url'              => $permalink,
            'datePublished'    => $published,
            'dateModified'     => $modified,
            'author'           => [
                '@type' => 'Person',
                'name'  => $author_name,
                'url'   => $author_url,
            ],
            'publisher' => [
                '@type' => 'Organization',
                'name'  => $site_name,
                'logo'  => $logo_url ? ['@type' => 'ImageObject', 'url' => $logo_url] : new stdClass(),
            ],
            'articleSection' => !empty($sections) ? $sections[0] : '',
            'inLanguage'     => 'en',
            'isAccessibleForFree' => true,
            'mainEntityOfPage' => [
                '@type' => 'WebPage',
                '@id'   => $permalink,
            ],
        ];

        if ($thumb_url) {
            $article['image'] = [
                '@type' => 'ImageObject',
                'url'   => $thumb_url,
            ];
        }

        // BreadcrumbList
        $breadcrumb = [
            '@context'        => 'https://schema.org',
            '@type'           => 'BreadcrumbList',
            'itemListElement' => [
                ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => $site_url],
            ],
        ];
        if (!empty($categories)) {
            $cat = $categories[0];
            $breadcrumb['itemListElement'][] = [
                '@type'    => 'ListItem',
                'position' => 2,
                'name'     => $cat->name,
                'item'     => get_category_link($cat->term_id),
            ];
            $breadcrumb['itemListElement'][] = [
                '@type'    => 'ListItem',
                'position' => 3,
                'name'     => $title,
                'item'     => $permalink,
            ];
        }

        echo '<script type="application/ld+json">' . wp_json_encode($article, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
        echo '<script type="application/ld+json">' . wp_json_encode($breadcrumb, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }

    echo '<script type="application/ld+json">' . wp_json_encode($website, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    echo '<script type="application/ld+json">' . wp_json_encode($org, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
}

// ── RELATED ARTICLES ──────────────────────────────────────────────

add_filter('the_content', 'tv_ads_related_posts', 99);
function tv_ads_related_posts($content) {
    if (!is_single() || !is_main_query()) return $content;
    if (get_option('tv_ads_related_posts', '1') !== '1') return $content;

    global $post;
    $categories = wp_get_post_categories($post->ID);
    if (empty($categories)) return $content;

    $related = get_posts([
        'category__in'   => $categories,
        'post__not_in'   => [$post->ID],
        'posts_per_page' => 4,
        'orderby'        => 'rand',
        'post_status'    => 'publish',
    ]);

    if (empty($related)) return $content;

    $html  = '<div class="tv-related-posts" style="margin:40px 0;padding:24px;background:#f8f9fa;border-radius:12px;border-left:4px solid #0070f3;">';
    $html .= '<h3 style="margin:0 0 20px;font-size:18px;font-weight:700;color:#111;">Related Articles</h3>';
    $html .= '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;">';

    foreach ($related as $r) {
        $thumb = get_the_post_thumbnail_url($r, 'medium') ?: '';
        $link  = get_permalink($r);
        $title = get_the_title($r);
        $date  = get_the_date('M j, Y', $r);
        $cats  = get_the_category($r->ID);
        $cat   = !empty($cats) ? $cats[0]->name : '';

        $html .= '<a href="' . esc_url($link) . '" style="display:block;text-decoration:none;color:inherit;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,0.08);transition:box-shadow 0.2s;" onmouseover="this.style.boxShadow=\'0 4px 12px rgba(0,0,0,0.15)\'" onmouseout="this.style.boxShadow=\'0 1px 4px rgba(0,0,0,0.08)\'">';
        if ($thumb) {
            $html .= '<img src="' . esc_url($thumb) . '" alt="' . esc_attr($title) . '" style="width:100%;height:130px;object-fit:cover;display:block;" loading="lazy" />';
        } else {
            $html .= '<div style="width:100%;height:130px;background:linear-gradient(135deg,#667eea,#764ba2);display:flex;align-items:center;justify-content:center;"><span style="font-size:28px;">📰</span></div>';
        }
        $html .= '<div style="padding:12px;">';
        if ($cat) $html .= '<span style="font-size:10px;text-transform:uppercase;letter-spacing:0.5px;color:#0070f3;font-weight:600;">' . esc_html($cat) . '</span>';
        $html .= '<p style="margin:4px 0 8px;font-size:14px;font-weight:600;color:#111;line-height:1.4;">' . esc_html(wp_trim_words($title, 10)) . '</p>';
        $html .= '<span style="font-size:11px;color:#999;">' . esc_html($date) . '</span>';
        $html .= '</div></a>';
    }

    $html .= '</div></div>';

    return $content . $html;
}

// ── CONNECTION TEST ───────────────────────────────────────────────

function tv_ads_test_connection($key) {
    if (empty($key)) return ['connected' => false, 'message' => 'No API key entered', 'ads' => []];
    $ads = tv_ads_fetch_codes($key, true);
    if (is_wp_error($ads)) return ['connected' => false, 'message' => $ads->get_error_message(), 'ads' => []];
    return ['connected' => true, 'message' => count($ads) . ' ad slot(s) active for ' . get_site_url(), 'ads' => $ads];
}

// ── FETCH AD CODES ────────────────────────────────────────────────

function tv_ads_fetch_codes($key = null, $force = false) {
    if (!$key) $key = get_option('tv_ads_publisher_key', '');
    if (empty($key)) return [];

    if (!$force) {
        $cached = get_transient(TV_ADS_CACHE_KEY);
        if ($cached !== false) return $cached;
    }

    $response = wp_remote_get(add_query_arg(['key' => $key, 'site' => get_site_url()], TV_ADS_API), [
        'timeout' => 15,
        'headers' => ['Accept' => 'application/json', 'User-Agent' => 'TrendingVerse-Ads/' . TV_ADS_VERSION],
    ]);

    if (is_wp_error($response)) return new WP_Error('api_error', 'Connection failed: ' . $response->get_error_message());

    $code = wp_remote_retrieve_response_code($response);
    $data = json_decode(wp_remote_retrieve_body($response), true);

    if ($code === 401) return new WP_Error('api_error', 'Invalid API key');
    if ($code !== 200) return new WP_Error('api_error', 'API returned status ' . $code);
    if (!isset($data['ads'])) return new WP_Error('api_error', 'Unexpected API response');

    set_transient(TV_ADS_CACHE_KEY, $data['ads'], TV_ADS_CACHE_TTL);
    return $data['ads'];
}

add_action('admin_init', function () {
    if (isset($_GET['refresh']) && $_GET['refresh'] === '1' && current_user_can('manage_options')) {
        delete_transient(TV_ADS_CACHE_KEY);
        delete_transient('tv_adstxt_cache');
        tv_ads_fetch_codes(null, true);
        wp_redirect(admin_url('options-general.php?page=trendingverse-ads&refreshed=1'));
        exit;
    }
});

// ── AD INJECTION ──────────────────────────────────────────────────

add_filter('the_content', 'tv_ads_inject', 20);
function tv_ads_inject($content) {
    if (!is_single() || !is_main_query()) return $content;
    if (get_option('tv_ads_enabled', '1') !== '1') return $content;

    $ads = tv_ads_fetch_codes();
    if (empty($ads) || is_wp_error($ads)) return $content;

    $header_ads = $footer_ads = '';
    $in_content = [];

    foreach ($ads as $ad) {
        if (empty($ad['is_enabled'])) continue;
        $pos = $ad['position'] ?? '';
        if ($pos === 'footer') {
            $html = tv_ads_build_sticky_anchor($ad);
        } else {
            $html = tv_ads_build_html($ad);
        }
        if (empty(trim($html))) continue;
        switch ($pos) {
            case 'header':     $header_ads .= $html; break;
            case 'footer':     $footer_ads .= $html; break;
            case 'in_content':
                $para = max(1, intval($ad['inject_after_paragraph'] ?? 2));
                $in_content[$para] = ($in_content[$para] ?? '') . $html;
                break;
        }
    }

    if (!empty($in_content)) {
        $parts  = explode('</p>', $content);
        $result = [];
        foreach ($parts as $i => $part) {
            $result[] = $part;
            if ($i < count($parts) - 1) {
                $result[] = '</p>';
                if (isset($in_content[$i + 1])) $result[] = $in_content[$i + 1];
            }
        }
        $content = implode('', $result);
    }

    // Footer sticky anchors are injected via wp_footer action, not inside content
    if (!empty($footer_ads)) {
        $footer_html = $footer_ads; // captured for closure
        add_action('wp_footer', function() use ($footer_html) {
            echo $footer_html; // phpcs:ignore WordPress.Security.EscapeOutput
        }, 100);
    }

    return $header_ads . $content;
}

function tv_ads_build_html($ad) {
    $outer = 'background:#f2f2f2;border-radius:4px;padding:8px 4px 4px;margin:20px auto;clear:both;text-align:center;max-width:100%;overflow:hidden;box-sizing:border-box;';
    $label = '<span style="display:block;font-size:9px;line-height:1;color:#999;letter-spacing:.5px;text-transform:uppercase;font-family:sans-serif;margin-bottom:4px;">Advertisement</span>';

    // Block restricted categories
    $blocked = ['casino', 'gambling', 'bet', 'poker', 'slots', 'lottery', 'adult', 'xxx', 'porn'];
    $code_lower = strtolower($ad['ad_code'] ?? '');
    foreach ($blocked as $kw) {
        if (strpos($code_lower, $kw) !== false) return '';
    }

    if (($ad['ad_type'] ?? '') === 'gam' && !empty($ad['gam_unit_path'])) {
        $div_id = 'tv-ad-' . substr(md5(($ad['id'] ?? '') . time()), 0, 12);
        $inner = sprintf(
            '<div id="%s"><script>window.googletag=window.googletag||{cmd:[]};googletag.cmd.push(function(){googletag.defineSlot("%s",[%d,%d],"%s").addService(googletag.pubads());googletag.pubads().enableSingleRequest();googletag.enableServices();googletag.display("%s");});</script></div>',
            esc_attr($div_id),
            esc_js($ad['gam_unit_path']),
            intval($ad['size_width'] ?? 300), intval($ad['size_height'] ?? 250),
            esc_attr($div_id), esc_attr($div_id)
        );
        return sprintf('<div style="%s">%s%s</div>' . "\n", esc_attr($outer), $label, $inner);
    }

    if (!empty($ad['ad_code'])) {
        return sprintf('<div style="%s">%s%s</div>' . "\n", esc_attr($outer), $label, $ad['ad_code']);
    }

    return '';
}

function tv_ads_build_sticky_anchor($ad) {
    // Block restricted categories
    $blocked = ['casino', 'gambling', 'bet', 'poker', 'slots', 'lottery', 'adult', 'xxx', 'porn'];
    $code_lower = strtolower($ad['ad_code'] ?? '');
    foreach ($blocked as $kw) {
        if (strpos($code_lower, $kw) !== false) return '';
    }

    $uid     = substr(md5(($ad['id'] ?? '') . time()), 0, 8);
    $wrap_id = 'tv-anchor-' . $uid;
    $w       = intval($ad['size_width'] ?? 320);
    $h       = intval($ad['size_height'] ?? 50);
    $pad     = $h + 20;

    if (($ad['ad_type'] ?? '') === 'gam' && !empty($ad['gam_unit_path'])) {
        $slot_id = 'gpt-anchor-' . $uid;
        $inner_html = sprintf(
            '<div id="%s"><script>window.googletag=window.googletag||{cmd:[]};googletag.cmd.push(function(){googletag.defineSlot("%s",[%d,%d],"%s").addService(googletag.pubads());googletag.pubads().enableSingleRequest();googletag.enableServices();googletag.display("%s");});</script></div>',
            esc_attr($slot_id),
            esc_js($ad['gam_unit_path']),
            $w, $h,
            esc_attr($slot_id), esc_attr($slot_id)
        );
    } elseif (!empty($ad['ad_code'])) {
        $inner_html = $ad['ad_code'];
    } else {
        return '';
    }

    return sprintf(
        '<div id="%1$s" style="position:fixed;bottom:0;left:0;right:0;z-index:99999;display:flex;justify-content:center;pointer-events:none;">' .
        '<div style="position:relative;pointer-events:all;background:#fff;box-shadow:0 -2px 10px rgba(0,0,0,.18);max-width:100vw;box-sizing:border-box;text-align:center;">' .
        '<button onclick="(function(){var e=document.getElementById(\'%1$s\');if(e){e.style.display=\'none\';document.body.style.paddingBottom=e.dataset.prevPad||\'\';}})();" ' .
            'style="position:absolute;top:-22px;right:0;background:rgba(0,0,0,.65);color:#fff;border:none;padding:1px 8px 2px;cursor:pointer;font-size:11px;line-height:1.6;border-radius:3px 3px 0 0;font-family:sans-serif;" ' .
            'aria-label="Close ad">&times; Close</button>' .
        '<div style="font-size:9px;line-height:1;color:#999;letter-spacing:.5px;text-transform:uppercase;font-family:sans-serif;padding:3px 0 2px;background:#f2f2f2;">Advertisement</div>' .
        '<div style="max-width:100vw;overflow:hidden;background:#f2f2f2;box-sizing:border-box;">%2$s</div>' .
        '</div></div>' .
        '<script>(function(){var e=document.getElementById(\'%1$s\');if(!e)return;e.dataset.prevPad=document.body.style.paddingBottom||\'\';document.body.style.paddingBottom=\'%3$dpx\';setTimeout(function(){var e2=document.getElementById(\'%1$s\');if(e2&&e2.style.display!==\'none\'){var i=e2.querySelector(\'div>div\');if(i)document.body.style.paddingBottom=(i.offsetHeight+20)+\'px\';}},1500);})();<\/script>' . "\n",
        esc_attr($wrap_id),
        $inner_html,
        $pad
    );
}

add_action('wp_head', function () {
    if (get_option('tv_ads_enabled', '1') !== '1') return;
    $ads = tv_ads_fetch_codes();
    if (empty($ads) || is_wp_error($ads)) return;
    foreach ($ads as $ad) {
        if (($ad['ad_type'] ?? '') === 'gam' && !empty($ad['gam_network_code'])) {
            echo '<script async src="https://securepubads.g.doubleclick.net/tag/js/gpt.js"></script>' . "\n";
            break;
        }
    }
}, 1);

// ── AUDIENCE TRACKING ─────────────────────────────────────────────

add_action('wp_head', 'tv_ads_inject_tracker', 5);
function tv_ads_inject_tracker() {
    $key              = get_option('tv_ads_publisher_key', '');
    $tracking_enabled = get_option('tv_ads_tracking_enabled', '1');
    $google_client_id = get_option('tv_ads_google_client_id', '');

    if (empty($key) || $tracking_enabled !== '1') return;

    $category = '';
    if (is_single()) {
        $cats = get_the_category();
        if (!empty($cats)) $category = esc_js($cats[0]->name);
    }

    echo '<script>';
    echo 'window.TV_SITE_URL = "' . esc_js(get_site_url()) . '";';
    echo 'window.TV_CATEGORY = "' . $category . '";';
    if (!empty($google_client_id)) {
        echo 'window.TV_GOOGLE_CLIENT_ID = "' . esc_js($google_client_id) . '";';
    }
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        if (!empty($current_user->user_email)) {
            echo 'window.TV_USER_EMAIL = "' . esc_js($current_user->user_email) . '";';
        }
    }
    echo '</script>' . "\n";
    echo '<script src="https://trendingverse-pages.pages.dev/tv-tracker.js" async defer></script>' . "\n";
}

// ── OPEN GRAPH / META IMPROVEMENTS ───────────────────────────────

add_action('wp_head', 'tv_ads_meta_tags', 1);
function tv_ads_meta_tags() {
    if (get_option('tv_ads_structured_data', '1') !== '1') return;
    // Only add if no other SEO plugin is handling OG (Yoast, Rank Math both do, so skip if active)
    if (defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION')) return;

    if (is_single()) {
        global $post;
        $title   = get_the_title($post);
        $excerpt = wp_strip_all_tags(get_the_excerpt($post));
        $thumb   = get_the_post_thumbnail_url($post, 'large') ?: get_site_icon_url(512);
        $url     = get_permalink($post);
        echo '<meta property="og:type" content="article" />' . "\n";
        echo '<meta property="og:title" content="' . esc_attr($title) . '" />' . "\n";
        echo '<meta property="og:description" content="' . esc_attr(substr($excerpt, 0, 200)) . '" />' . "\n";
        echo '<meta property="og:url" content="' . esc_url($url) . '" />' . "\n";
        if ($thumb) echo '<meta property="og:image" content="' . esc_url($thumb) . '" />' . "\n";
        echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr($title) . '" />' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr(substr($excerpt, 0, 200)) . '" />' . "\n";
        if ($thumb) echo '<meta name="twitter:image" content="' . esc_url($thumb) . '" />' . "\n";
    }
}

// ── SCHEDULED TASKS ───────────────────────────────────────────────

register_activation_hook(__FILE__, function () {
    if (!wp_next_scheduled('tv_ads_hourly_refresh'))
        wp_schedule_event(time(), 'hourly', 'tv_ads_hourly_refresh');
});

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('tv_ads_hourly_refresh');
    delete_transient(TV_ADS_CACHE_KEY);
    delete_transient('tv_adstxt_cache');
});

add_action('tv_ads_hourly_refresh', function () {
    tv_ads_fetch_codes(null, true);
    delete_transient('tv_adstxt_cache'); // force ads.txt refresh too
});
