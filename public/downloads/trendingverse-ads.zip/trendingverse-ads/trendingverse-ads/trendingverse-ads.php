<?php
/**
 * Plugin Name: TrendingVerse Ads
 * Plugin URI: https://trendingverse.vercel.app
 * Description: Automatically fetches and injects monetization ads from TrendingVerse CMS. Content-aware placement with lazy loading. Includes audience tracking for first-party data collection.
 * Version: 1.0.4
 * Author: TrendingVerse
 * Author URI: https://trendingverse.vercel.app
 * License: GPL2
 */
if (!defined('ABSPATH')) exit;
define('TV_ADS_VERSION',    '1.0.4');
define('TV_ADS_API',        'https://trendingverse.vercel.app/api/admin/publishers/ad-codes');
define('TV_ADS_UPDATE_URL', 'https://trendingverse.vercel.app/api/plugin/update-check');
define('TV_ADS_DOWNLOAD',   'https://trendingverse.vercel.app/api/plugin/download');
define('TV_TRACKER_URL',    'https://trendingverse.vercel.app/api/audience/track');
define('TV_ADS_CACHE_KEY',  'tv_ads_cache');
define('TV_ADS_CACHE_TTL',  3600);

// Content-aware placement tuning
define('TV_ADS_MIN_PARA_BEFORE_FIRST', 3);   // never inject before this paragraph
define('TV_ADS_PARA_GAP',              4);   // minimum paragraphs between in-content ads
define('TV_ADS_MAX_INCONTENT',         6);   // hard cap on in-content ads per article

// ── AUTO-UPDATE MECHANISM ────────────────────────────────────────
add_filter('pre_set_site_transient_update_plugins', 'tv_ads_check_update');
function tv_ads_check_update($transient) {
    if (empty($transient->checked)) return $transient;
    $response = wp_remote_get(TV_ADS_UPDATE_URL, [
        'timeout' => 10,
        'headers' => ['Accept' => 'application/json'],
    ]);
    if (is_wp_error($response)) return $transient;
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($data['version'])) return $transient;
    if (version_compare(TV_ADS_VERSION, $data['version'], '<')) {
        $transient->response['trendingverse-ads/trendingverse-ads.php'] = (object) [
            'slug'        => 'trendingverse-ads',
            'plugin'      => 'trendingverse-ads/trendingverse-ads.php',
            'new_version' => $data['version'],
            'url'         => 'https://trendingverse.vercel.app',
            'package'     => TV_ADS_DOWNLOAD,
        ];
    }
    return $transient;
}
add_filter('plugins_api', 'tv_ads_plugin_info', 20, 3);
function tv_ads_plugin_info($result, $action, $args) {
    if ($action !== 'plugin_information') return $result;
    if (!isset($args->slug) || $args->slug !== 'trendingverse-ads') return $result;
    $response = wp_remote_get(TV_ADS_UPDATE_URL . '?action=info', [
        'timeout' => 10,
        'headers' => ['Accept' => 'application/json'],
    ]);
    if (is_wp_error($response)) return $result;
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($data)) return $result;
    return (object) [
        'name'          => $data['name']         ?? 'TrendingVerse Ads',
        'slug'          => 'trendingverse-ads',
        'version'       => $data['version']      ?? TV_ADS_VERSION,
        'author'        => $data['author']        ?? 'TrendingVerse',
        'last_updated'  => $data['last_updated']  ?? '',
        'requires'      => $data['requires']      ?? '5.0',
        'tested'        => $data['tested']        ?? '6.5',
        'download_link' => TV_ADS_DOWNLOAD,
        'sections'      => $data['sections']      ?? [],
    ];
}
// ── ADMIN SETTINGS PAGE ──────────────────────────────────────────
add_action('admin_menu', function () {
    add_options_page('TrendingVerse Ads', 'TrendingVerse Ads', 'manage_options', 'trendingverse-ads', 'tv_ads_settings_page');
});
add_action('admin_init', function () {
    register_setting('tv_ads_settings', 'tv_ads_publisher_key');
    register_setting('tv_ads_settings', 'tv_ads_enabled');
    register_setting('tv_ads_settings', 'tv_ads_tracking_enabled');
    register_setting('tv_ads_settings', 'tv_ads_lazyload_enabled');
    register_setting('tv_ads_settings', 'tv_ads_auto_density');
});
function tv_ads_settings_page() {
    $key              = get_option('tv_ads_publisher_key', '');
    $enabled          = get_option('tv_ads_enabled', '1');
    $tracking_enabled = get_option('tv_ads_tracking_enabled', '1');
    $lazyload         = get_option('tv_ads_lazyload_enabled', '1');
    $auto_density     = get_option('tv_ads_auto_density', '1');
    $status           = tv_ads_test_connection($key);
    $refreshed        = isset($_GET['refreshed']);
    ?>
    <div class="wrap">
        <h1>🎯 TrendingVerse Ads
            <span style="font-size:12px;background:#111;color:#fff;padding:2px 8px;border-radius:20px;font-weight:400;">v<?php echo TV_ADS_VERSION; ?></span>
        </h1>
        <p style="color:#666;">Content-aware ad injection with lazy loading + first-party audience data from TrendingVerse CMS.</p>
        <?php if ($refreshed): ?>
        <div class="notice notice-info is-dismissible"><p>Ad codes refreshed successfully.</p></div>
        <?php endif; ?>
        <?php if (!empty($key)): ?>
            <?php if ($status['connected']): ?>
            <div class="notice notice-success" style="padding:12px 16px;">
                <strong>✓ Connected</strong> — <?php echo esc_html($status['message']); ?>
            </div>
            <?php else: ?>
            <div class="notice notice-error" style="padding:12px 16px;">
                <strong>✗ Not connected</strong> — <?php echo esc_html($status['message']); ?>
            </div>
            <?php endif; ?>
        <?php endif; ?>
        <form method="post" action="options.php" style="margin-top:24px;">
            <?php settings_fields('tv_ads_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="tv_ads_publisher_key">Publisher API Key</label></th>
                    <td>
                        <input type="text" id="tv_ads_publisher_key" name="tv_ads_publisher_key"
                            value="<?php echo esc_attr($key); ?>"
                            style="width:420px;font-family:monospace;font-size:13px;"
                            placeholder="tvp_xxxxxxxxxxxxxxxxxxxxxxxx" />
                        <p class="description">
                            Get your key from <a href="https://trendingverse.vercel.app/admin/settings" target="_blank">
                            TrendingVerse CMS → Settings → API Keys</a>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_enabled">Enable Ads</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_enabled" name="tv_ads_enabled" value="1"
                                <?php checked($enabled, '1'); ?> />
                            Inject ads into all articles automatically
                        </label>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_auto_density">Auto Density</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_auto_density" name="tv_ads_auto_density" value="1"
                                <?php checked($auto_density, '1'); ?> />
                            Scale number of in-content ads to article length
                        </label>
                        <p class="description">When on, longer articles get more in-content ads (1 per ~<?php echo TV_ADS_PARA_GAP; ?> paragraphs, capped at <?php echo TV_ADS_MAX_INCONTENT; ?>). When off, uses the exact positions set in your CMS.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_lazyload_enabled">Lazy Loading</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_lazyload_enabled" name="tv_ads_lazyload_enabled" value="1"
                                <?php checked($lazyload, '1'); ?> />
                            Only load ads when they're about to enter the viewport
                        </label>
                        <p class="description">Improves viewability (Active View %) and page speed. Ads render ~600px before they scroll into view.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_tracking_enabled">Audience Tracking</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_tracking_enabled" name="tv_ads_tracking_enabled" value="1"
                                <?php checked($tracking_enabled, '1'); ?> />
                            Collect anonymous first-party reader data (pageviews, location, device, interests)
                        </label>
                        <p class="description">Enables lead capture popup. Data sent to TrendingVerse CMS only.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save & Connect'); ?>
        </form>
        <?php if ($status['connected'] && !empty($status['ads'])): ?>
        <h2 style="margin-top:32px;">Ad Slots Configured (<?php echo count($status['ads']); ?>)</h2>
        <p style="color:#666;font-size:13px;">These are your slot <em>definitions</em>. With Auto Density on, in-content slots are repeated and spaced automatically based on each article's length.</p>
        <table class="wp-list-table widefat fixed striped" style="max-width:600px;">
            <thead>
                <tr><th width="40">#</th><th>Position</th><th>After Paragraph</th><th>Size</th><th>Type</th></tr>
            </thead>
            <tbody>
                <?php foreach ($status['ads'] as $i => $ad): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><?php echo esc_html($ad['position'] ?? '—'); ?></td>
                    <td><?php echo ($ad['position'] === 'in_content') ? esc_html($ad['inject_after_paragraph'] ?? 2) : '—'; ?></td>
                    <td><?php echo esc_html(($ad['size_width'] ?? '') . 'x' . ($ad['size_height'] ?? '')); ?></td>
                    <td><code><?php echo esc_html(strtoupper($ad['ad_type'] ?? '')); ?></code></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p style="margin-top:16px;">
            <a href="<?php echo esc_url(admin_url('options-general.php?page=trendingverse-ads&refresh=1')); ?>"
                class="button button-secondary">↺ Refresh Ad Codes Now</a>
            <span style="color:#999;font-size:12px;margin-left:12px;">Auto-refreshes every hour</span>
        </p>
        <?php endif; ?>
    </div>
    <?php
}
// ── CONNECTION TEST ───────────────────────────────────────────────
function tv_ads_test_connection($key) {
    if (empty($key)) return ['connected' => false, 'message' => 'No API key entered', 'ads' => []];
    $ads = tv_ads_fetch_codes($key, true);
    if (is_wp_error($ads)) return ['connected' => false, 'message' => $ads->get_error_message(), 'ads' => []];
    return ['connected' => true, 'message' => count($ads) . ' ad slot(s) active for ' . get_site_url(), 'ads' => $ads];
}
// ── FETCH AD CODES ────────────────────────────────────────────────
function tv_ads_fetch_codes($key = null, $force = false) {
    if (!$key) $key = get_option('tv_ads_publisher_key', '');
    if (empty($key)) return [];
    if (!$force) {
        $cached = get_transient(TV_ADS_CACHE_KEY);
        if ($cached !== false) return $cached;
    }
    $response = wp_remote_get(add_query_arg(['key' => $key, 'site' => get_site_url()], TV_ADS_API), [
        'timeout' => 15,
        'headers' => ['Accept' => 'application/json', 'User-Agent' => 'TrendingVerse-Ads/' . TV_ADS_VERSION],
    ]);
    if (is_wp_error($response)) return new WP_Error('api_error', 'Connection failed: ' . $response->get_error_message());
    $code = wp_remote_retrieve_response_code($response);
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if ($code === 401) return new WP_Error('api_error', 'Invalid API key');
    if ($code !== 200) return new WP_Error('api_error', 'API returned status ' . $code);
    if (!isset($data['ads'])) return new WP_Error('api_error', 'Unexpected API response');
    set_transient(TV_ADS_CACHE_KEY, $data['ads'], TV_ADS_CACHE_TTL);
    return $data['ads'];
}
add_action('admin_init', function () {
    if (isset($_GET['refresh']) && $_GET['refresh'] === '1' && current_user_can('manage_options')) {
        delete_transient(TV_ADS_CACHE_KEY);
        tv_ads_fetch_codes(null, true);
        wp_redirect(admin_url('options-general.php?page=trendingverse-ads&refreshed=1'));
        exit;
    }
});

// ── AD INJECTION — content-aware placement ───────────────────────
add_filter('the_content', 'tv_ads_inject', 20);
function tv_ads_inject($content) {
    if (!is_single() || !is_main_query()) return $content;
    if (get_option('tv_ads_enabled', '1') !== '1') return $content;
    $ads = tv_ads_fetch_codes();
    if (empty($ads) || is_wp_error($ads)) return $content;

    $auto_density = get_option('tv_ads_auto_density', '1') === '1';

    // Separate ads by position
    $header_ads = $footer_ads = '';
    $incontent_templates = [];  // the in-content ad definitions to cycle through
    foreach ($ads as $ad) {
        if (empty($ad['is_enabled'])) continue;
        $html = tv_ads_build_html($ad);
        if (empty(trim($html))) continue;
        switch ($ad['position'] ?? '') {
            case 'header': $header_ads .= $html; break;
            case 'footer': $footer_ads .= $html; break;
            case 'in_content': $incontent_templates[] = $ad; break;
        }
    }

    // Split content into paragraphs
    $parts = explode('</p>', $content);
    $para_count = max(0, count($parts) - 1); // number of closed <p> blocks

    if (!empty($incontent_templates) && $para_count >= TV_ADS_MIN_PARA_BEFORE_FIRST) {

        // Build the list of paragraph indexes (1-based) where ads should go
        $slots = [];

        if ($auto_density) {
            // Content-aware: one ad every TV_ADS_PARA_GAP paragraphs,
            // starting at MIN_PARA_BEFORE_FIRST, capped at MAX_INCONTENT.
            $pos = TV_ADS_MIN_PARA_BEFORE_FIRST;
            while ($pos <= $para_count && count($slots) < TV_ADS_MAX_INCONTENT) {
                $slots[] = $pos;
                $pos += TV_ADS_PARA_GAP;
            }
        } else {
            // Manual: use the exact inject_after_paragraph from each definition,
            // but still enforce the "not before paragraph 3" floor.
            foreach ($incontent_templates as $ad) {
                $p = max(TV_ADS_MIN_PARA_BEFORE_FIRST, intval($ad['inject_after_paragraph'] ?? 2));
                if ($p <= $para_count && !in_array($p, $slots)) $slots[] = $p;
            }
            sort($slots);
        }

        // Assign an ad template to each slot, cycling through available templates
        $slot_html = [];
        $t = 0;
        foreach ($slots as $slot_para) {
            $ad = $incontent_templates[$t % count($incontent_templates)];
            $slot_html[$slot_para] = tv_ads_build_html($ad);
            $t++;
        }

        // Rebuild the content with ads inserted after the chosen paragraphs
        $result = [];
        foreach ($parts as $i => $part) {
            $result[] = $part;
            if ($i < count($parts) - 1) {
                $result[] = '</p>';
                $para_num = $i + 1;
                if (isset($slot_html[$para_num])) {
                    $result[] = $slot_html[$para_num];
                }
            }
        }
        $content = implode('', $result);
    }

    return $header_ads . $content . $footer_ads;
}

function tv_ads_build_html($ad) {
    $wrap = 'text-align:center;margin:20px auto;clear:both;line-height:0;min-height:' . intval($ad['size_height'] ?? 250) . 'px;';
    $lazy = get_option('tv_ads_lazyload_enabled', '1') === '1';

    // Block restricted categories (brand safety)
    $blocked = ['casino', 'gambling', 'bet', 'poker', 'slots', 'lottery', 'adult', 'xxx', 'porn', 'one-vv5163.com'];
    $code_lower = strtolower($ad['ad_code'] ?? '');
    foreach ($blocked as $kw) {
        if (strpos($code_lower, $kw) !== false) return '';
    }

    if (($ad['ad_type'] ?? '') === 'gam' && !empty($ad['gam_unit_path'])) {
        $div_id = 'tv-ad-' . substr(md5(($ad['id'] ?? '') . uniqid('', true)), 0, 12);
        $w = intval($ad['size_width'] ?? 300);
        $h = intval($ad['size_height'] ?? 250);

        if ($lazy) {
            // Lazy: define the slot now but DON'T display until near viewport.
            // The shared IntersectionObserver (printed in footer) calls display().
            return sprintf(
                '<div id="%s" class="tv-lazy-ad" data-gam-path="%s" data-w="%d" data-h="%d" style="%s"></div>' . "\n",
                esc_attr($div_id),
                esc_attr($ad['gam_unit_path']),
                $w, $h, esc_attr($wrap)
            );
        }

        // Non-lazy: original inline display behaviour
        return sprintf(
            '<div id="%s" style="%s"><script>window.googletag=window.googletag||{cmd:[]};googletag.cmd.push(function(){googletag.defineSlot("%s",[%d,%d],"%s").addService(googletag.pubads());googletag.pubads().enableSingleRequest();googletag.enableServices();googletag.display("%s");});</script></div>' . "\n",
            esc_attr($div_id), esc_attr($wrap),
            esc_js($ad['gam_unit_path']), $w, $h,
            esc_attr($div_id), esc_attr($div_id)
        );
    }

    if (!empty($ad['ad_code'])) {
        if ($lazy) {
            // Wrap raw ad code so it only writes into the DOM when near viewport
            $encoded = base64_encode($ad['ad_code']);
            return sprintf(
                '<div class="tv-lazy-ad" data-adcode="%s" style="%s"></div>' . "\n",
                esc_attr($encoded), esc_attr($wrap)
            );
        }
        return sprintf('<div style="%s">%s</div>' . "\n", esc_attr($wrap), $ad['ad_code']);
    }
    return '';
}

// GPT library + lazy-load observer in the head/footer
add_action('wp_head', function () {
    if (get_option('tv_ads_enabled', '1') !== '1') return;
    $ads = tv_ads_fetch_codes();
    if (empty($ads) || is_wp_error($ads)) return;
    foreach ($ads as $ad) {
        if (($ad['ad_type'] ?? '') === 'gam' && !empty($ad['gam_network_code'])) {
            echo '<script async src="https://securepubads.g.doubleclick.net/tag/js/gpt.js"></script>' . "\n";
            echo '<script>window.googletag=window.googletag||{cmd:[]};googletag.cmd.push(function(){googletag.pubads().enableSingleRequest();googletag.enableServices();});</script>' . "\n";
            break;
        }
    }
}, 1);

// ── LAZY-LOAD OBSERVER ────────────────────────────────────────────
add_action('wp_footer', function () {
    if (get_option('tv_ads_enabled', '1') !== '1') return;
    if (get_option('tv_ads_lazyload_enabled', '1') !== '1') return;
    ?>
<script>
(function () {
  var lazyAds = document.querySelectorAll('.tv-lazy-ad');
  if (!lazyAds.length) return;

  function loadAd(el) {
    if (el.dataset.loaded === '1') return;
    el.dataset.loaded = '1';

    // GAM slot
    if (el.dataset.gamPath) {
      var w = parseInt(el.dataset.w, 10) || 300;
      var h = parseInt(el.dataset.h, 10) || 250;
      var id = el.id;
      window.googletag = window.googletag || { cmd: [] };
      googletag.cmd.push(function () {
        var slot = googletag.defineSlot(el.dataset.gamPath, [w, h], id);
        if (slot) {
          slot.addService(googletag.pubads());
          googletag.display(id);
          googletag.pubads().refresh([slot]);
        }
      });
      return;
    }

    // Raw ad code (base64-encoded to survive as an attribute)
    if (el.dataset.adcode) {
      try {
        var html = atob(el.dataset.adcode);
        // Use a range so any inline <script> in the ad code executes
        var range = document.createRange();
        range.selectNode(el);
        var frag = range.createContextualFragment(html);
        el.appendChild(frag);
      } catch (e) { /* ignore malformed ad code */ }
    }
  }

  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          loadAd(entry.target);
          io.unobserve(entry.target);
        }
      });
    }, { rootMargin: '600px 0px' }); // start loading 600px before it enters view
    lazyAds.forEach(function (el) { io.observe(el); });
  } else {
    // Fallback for very old browsers — just load everything
    lazyAds.forEach(loadAd);
  }
})();
</script>
    <?php
});

// ── AUDIENCE TRACKING ─────────────────────────────────────────────
add_action('wp_head', 'tv_ads_inject_tracker', 5);
function tv_ads_inject_tracker() {
    $key              = get_option('tv_ads_publisher_key', '');
    $tracking_enabled = get_option('tv_ads_tracking_enabled', '1');
    if (empty($key) || $tracking_enabled !== '1') return;
    $category = '';
    if (is_single()) {
        $cats = get_the_category();
        if (!empty($cats)) $category = esc_js($cats[0]->name);
    }
    $site_url = esc_js(get_site_url());
    echo '<script>';
    echo 'window.TV_SITE_URL = "' . $site_url . '";';
    echo 'window.TV_CATEGORY = "' . $category . '";';
    echo '</script>';
    echo '<script src="https://trendingverse.vercel.app/tv-tracker.js" async defer></script>' . "\n";
}
// ── SCHEDULED TASKS ───────────────────────────────────────────────
register_activation_hook(__FILE__, function () {
    if (!wp_next_scheduled('tv_ads_hourly_refresh'))
        wp_schedule_event(time(), 'hourly', 'tv_ads_hourly_refresh');
});
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('tv_ads_hourly_refresh');
    delete_transient(TV_ADS_CACHE_KEY);
});
add_action('tv_ads_hourly_refresh', function () {
    tv_ads_fetch_codes(null, true);
});