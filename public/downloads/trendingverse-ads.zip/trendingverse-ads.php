<?php
/**
 * Plugin Name: TrendingVerse Ads
 * Plugin URI: https://trendingverse.vercel.app
 * Description: Fetches and injects monetization ads from TrendingVerse CMS. Every slot serves via the central mediation waterfall (direct-first, then network partners by priority). Content-aware placement, lazy loading, viewability + per-partner tracking, popunder support, first-party audience data.
 * Version: 1.0.7
 * Author: TrendingVerse
 * Author URI: https://trendingverse.vercel.app
 * License: GPL2
 */
if (!defined('ABSPATH')) exit;
define('TV_ADS_VERSION',    '1.0.7');
define('TV_ADS_API',        'https://trendingverse.vercel.app/api/admin/publishers/ad-codes');
define('TV_ADS_UPDATE_URL', 'https://trendingverse.vercel.app/api/plugin/update-check');
define('TV_ADS_DOWNLOAD',   'https://trendingverse.vercel.app/api/plugin/download');
define('TV_TRACKER_URL',    'https://trendingverse.vercel.app/api/audience/track');
define('TV_SERVE_AD_API',   'https://trendingverse.vercel.app/api/audience/serve-ad');
define('TV_SERVE_SLOT_API', 'https://trendingverse.vercel.app/api/mediation/serve-slot');
define('TV_AD_CLICK_API',   'https://trendingverse.vercel.app/api/audience/ad-click');
define('TV_AD_VIEW_API',    'https://trendingverse.vercel.app/api/audience/ad-viewable');
define('TV_MEVENT_API',     'https://trendingverse.vercel.app/api/mediation/event');
define('TV_POPUNDER_API',   'https://trendingverse.vercel.app/api/mediation/popunder');
define('TV_ADS_CACHE_KEY',  'tv_ads_cache');
define('TV_ADS_CACHE_TTL',  3600);
// Content-aware placement tuning
define('TV_ADS_MIN_PARA_BEFORE_FIRST', 3);
define('TV_ADS_PARA_GAP',              4);
define('TV_ADS_MAX_INCONTENT',         6);
// ── AUTO-UPDATE MECHANISM ────────────────────────────────────────
add_filter('pre_set_site_transient_update_plugins', 'tv_ads_check_update');
function tv_ads_check_update($transient) {
    if (empty($transient->checked)) return $transient;
    $response = wp_remote_get(TV_ADS_UPDATE_URL, [
        'timeout' => 10,
        'headers' => ['Accept' => 'application/json'],
    ]);
    if (is_wp_error($response)) return $transient;
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($data['version'])) return $transient;
    if (version_compare(TV_ADS_VERSION, $data['version'], '<')) {
        $transient->response['trendingverse-ads/trendingverse-ads.php'] = (object) [
            'slug'        => 'trendingverse-ads',
            'plugin'      => 'trendingverse-ads/trendingverse-ads.php',
            'new_version' => $data['version'],
            'url'         => 'https://trendingverse.vercel.app',
            'package'     => TV_ADS_DOWNLOAD,
        ];
    }
    return $transient;
}
add_filter('plugins_api', 'tv_ads_plugin_info', 20, 3);
function tv_ads_plugin_info($result, $action, $args) {
    if ($action !== 'plugin_information') return $result;
    if (!isset($args->slug) || $args->slug !== 'trendingverse-ads') return $result;
    $response = wp_remote_get(TV_ADS_UPDATE_URL . '?action=info', [
        'timeout' => 10,
        'headers' => ['Accept' => 'application/json'],
    ]);
    if (is_wp_error($response)) return $result;
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($data)) return $result;
    return (object) [
        'name'          => $data['name']         ?? 'TrendingVerse Ads',
        'slug'          => 'trendingverse-ads',
        'version'       => $data['version']      ?? TV_ADS_VERSION,
        'author'        => $data['author']        ?? 'TrendingVerse',
        'last_updated'  => $data['last_updated']  ?? '',
        'requires'      => $data['requires']      ?? '5.0',
        'tested'        => $data['tested']        ?? '6.5',
        'download_link' => TV_ADS_DOWNLOAD,
        'sections'      => $data['sections']      ?? [],
    ];
}
// ── ADMIN SETTINGS PAGE ──────────────────────────────────────────
add_action('admin_menu', function () {
    add_options_page('TrendingVerse Ads', 'TrendingVerse Ads', 'manage_options', 'trendingverse-ads', 'tv_ads_settings_page');
});
add_action('admin_init', function () {
    register_setting('tv_ads_settings', 'tv_ads_publisher_key');
    register_setting('tv_ads_settings', 'tv_ads_enabled');
    register_setting('tv_ads_settings', 'tv_ads_tracking_enabled');
    register_setting('tv_ads_settings', 'tv_ads_lazyload_enabled');
    register_setting('tv_ads_settings', 'tv_ads_auto_density');
    register_setting('tv_ads_settings', 'tv_ads_direct_enabled');
});
function tv_ads_settings_page() {
    $key              = get_option('tv_ads_publisher_key', '');
    $enabled          = get_option('tv_ads_enabled', '1');
    $tracking_enabled = get_option('tv_ads_tracking_enabled', '1');
    $lazyload         = get_option('tv_ads_lazyload_enabled', '1');
    $auto_density     = get_option('tv_ads_auto_density', '1');
    $direct_enabled   = get_option('tv_ads_direct_enabled', '1');
    $status           = tv_ads_test_connection($key);
    $refreshed        = isset($_GET['refreshed']);
    ?>
    <div class="wrap">
        <h1>🎯 TrendingVerse Ads
            <span style="font-size:12px;background:#111;color:#fff;padding:2px 8px;border-radius:20px;font-weight:400;">v<?php echo TV_ADS_VERSION; ?></span>
        </h1>
        <p style="color:#666;">Every slot serves via the central mediation waterfall — direct campaigns first, then network partners by priority. Managed from your CMS Ad Networks screen.</p>
        <?php if ($refreshed): ?>
        <div class="notice notice-info is-dismissible"><p>Ad codes refreshed successfully.</p></div>
        <?php endif; ?>
        <?php if (!empty($key)): ?>
            <?php if ($status['connected']): ?>
            <div class="notice notice-success" style="padding:12px 16px;">
                <strong>✓ Connected</strong> — <?php echo esc_html($status['message']); ?>
            </div>
            <?php else: ?>
            <div class="notice notice-error" style="padding:12px 16px;">
                <strong>✗ Not connected</strong> — <?php echo esc_html($status['message']); ?>
            </div>
            <?php endif; ?>
        <?php endif; ?>
        <form method="post" action="options.php" style="margin-top:24px;">
            <?php settings_fields('tv_ads_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="tv_ads_publisher_key">Publisher API Key</label></th>
                    <td>
                        <input type="text" id="tv_ads_publisher_key" name="tv_ads_publisher_key"
                            value="<?php echo esc_attr($key); ?>"
                            style="width:420px;font-family:monospace;font-size:13px;"
                            placeholder="tvp_xxxxxxxxxxxxxxxxxxxxxxxx" />
                        <p class="description">
                            Get your key from <a href="https://trendingverse.vercel.app/admin/settings" target="_blank">
                            TrendingVerse CMS → Settings → API Keys</a>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_enabled">Enable Ads</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_enabled" name="tv_ads_enabled" value="1"
                                <?php checked($enabled, '1'); ?> />
                            Inject ads into all articles automatically
                        </label>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_direct_enabled">Direct Campaigns</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_direct_enabled" name="tv_ads_direct_enabled" value="1"
                                <?php checked($direct_enabled, '1'); ?> />
                            Give direct-sold campaigns first look at each ad slot
                        </label>
                        <p class="description">Direct campaigns fill the slot when eligible; network partners serve as the waterfall backfill.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_auto_density">Auto Density</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_auto_density" name="tv_ads_auto_density" value="1"
                                <?php checked($auto_density, '1'); ?> />
                            Scale number of in-content ads to article length
                        </label>
                        <p class="description">When on, longer articles get more in-content ads (1 per ~<?php echo TV_ADS_PARA_GAP; ?> paragraphs, capped at <?php echo TV_ADS_MAX_INCONTENT; ?>). When off, uses the exact positions set in your CMS.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_lazyload_enabled">Lazy Loading</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_lazyload_enabled" name="tv_ads_lazyload_enabled" value="1"
                                <?php checked($lazyload, '1'); ?> />
                            Only load ads when they're about to enter the viewport
                        </label>
                        <p class="description">Improves viewability (Active View %) and page speed. Ads render ~600px before they scroll into view.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tv_ads_tracking_enabled">Audience Tracking</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="tv_ads_tracking_enabled" name="tv_ads_tracking_enabled" value="1"
                                <?php checked($tracking_enabled, '1'); ?> />
                            Collect anonymous first-party reader data (pageviews, location, device, interests)
                        </label>
                        <p class="description">Enables lead capture popup + direct-ad targeting. Data sent to TrendingVerse CMS only.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save & Connect'); ?>
        </form>
        <?php if ($status['connected'] && !empty($status['ads'])): ?>
        <h2 style="margin-top:32px;">Ad Slots Configured (<?php echo count($status['ads']); ?>)</h2>
        <p style="color:#666;font-size:13px;">These are your slot <em>definitions</em>. Each becomes a smart slot that serves the central mediation waterfall (direct → network partners by priority).</p>
        <table class="wp-list-table widefat fixed striped" style="max-width:600px;">
            <thead>
                <tr><th width="40">#</th><th>Position</th><th>After Paragraph</th><th>Size</th><th>Type</th></tr>
            </thead>
            <tbody>
                <?php foreach ($status['ads'] as $i => $ad): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><?php echo esc_html($ad['position'] ?? '—'); ?></td>
                    <td><?php echo ($ad['position'] === 'in_content') ? esc_html($ad['inject_after_paragraph'] ?? 2) : '—'; ?></td>
                    <td><?php echo esc_html(($ad['size_width'] ?? '') . 'x' . ($ad['size_height'] ?? '')); ?></td>
                    <td><code><?php echo esc_html(strtoupper($ad['ad_type'] ?? '')); ?></code></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p style="margin-top:16px;">
            <a href="<?php echo esc_url(admin_url('options-general.php?page=trendingverse-ads&refresh=1')); ?>"
                class="button button-secondary">↺ Refresh Ad Codes Now</a>
            <span style="color:#999;font-size:12px;margin-left:12px;">Auto-refreshes every hour</span>
        </p>
        <?php endif; ?>
    </div>
    <?php
}
// ── CONNECTION TEST ───────────────────────────────────────────────
function tv_ads_test_connection($key) {
    if (empty($key)) return ['connected' => false, 'message' => 'No API key entered', 'ads' => []];
    $ads = tv_ads_fetch_codes($key, true);
    if (is_wp_error($ads)) return ['connected' => false, 'message' => $ads->get_error_message(), 'ads' => []];
    return ['connected' => true, 'message' => count($ads) . ' ad slot(s) active for ' . get_site_url(), 'ads' => $ads];
}
// ── FETCH AD CODES (slot definitions) ─────────────────────────────
function tv_ads_fetch_codes($key = null, $force = false) {
    if (!$key) $key = get_option('tv_ads_publisher_key', '');
    if (empty($key)) return [];
    if (!$force) {
        $cached = get_transient(TV_ADS_CACHE_KEY);
        if ($cached !== false) return $cached;
    }
    $response = wp_remote_get(add_query_arg(['key' => $key, 'site' => get_site_url()], TV_ADS_API), [
        'timeout' => 15,
        'headers' => ['Accept' => 'application/json', 'User-Agent' => 'TrendingVerse-Ads/' . TV_ADS_VERSION],
    ]);
    if (is_wp_error($response)) return new WP_Error('api_error', 'Connection failed: ' . $response->get_error_message());
    $code = wp_remote_retrieve_response_code($response);
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if ($code === 401) return new WP_Error('api_error', 'Invalid API key');
    if ($code !== 200) return new WP_Error('api_error', 'API returned status ' . $code);
    if (!isset($data['ads'])) return new WP_Error('api_error', 'Unexpected API response');
    set_transient(TV_ADS_CACHE_KEY, $data['ads'], TV_ADS_CACHE_TTL);
    return $data['ads'];
}
add_action('admin_init', function () {
    if (isset($_GET['refresh']) && $_GET['refresh'] === '1' && current_user_can('manage_options')) {
        delete_transient(TV_ADS_CACHE_KEY);
        delete_transient('tv_popunder_' . md5(get_site_url()));
        tv_ads_fetch_codes(null, true);
        wp_redirect(admin_url('options-general.php?page=trendingverse-ads&refreshed=1'));
        exit;
    }
});
// ── AD INJECTION — content-aware placement ───────────────────────
add_filter('the_content', 'tv_ads_inject', 20);
function tv_ads_inject($content) {
    if (!is_single() || !is_main_query()) return $content;
    if (get_option('tv_ads_enabled', '1') !== '1') return $content;
    $ads = tv_ads_fetch_codes();
    if (empty($ads) || is_wp_error($ads)) return $content;
    $auto_density = get_option('tv_ads_auto_density', '1') === '1';
    $header_ads = $footer_ads = '';
    $incontent_templates = [];
    foreach ($ads as $ad) {
        if (empty($ad['is_enabled'])) continue;
        $html = tv_ads_build_html($ad);
        if (empty(trim($html))) continue;
        switch ($ad['position'] ?? '') {
            case 'header': $header_ads .= $html; break;
            case 'footer': $footer_ads .= $html; break;
            case 'in_content': $incontent_templates[] = $ad; break;
        }
    }
    $parts = explode('</p>', $content);
    $para_count = max(0, count($parts) - 1);
    if (!empty($incontent_templates) && $para_count >= TV_ADS_MIN_PARA_BEFORE_FIRST) {
        $slots = [];
        if ($auto_density) {
            $pos = TV_ADS_MIN_PARA_BEFORE_FIRST;
            while ($pos <= $para_count && count($slots) < TV_ADS_MAX_INCONTENT) {
                $slots[] = $pos;
                $pos += TV_ADS_PARA_GAP;
            }
        } else {
            foreach ($incontent_templates as $ad) {
                $p = max(TV_ADS_MIN_PARA_BEFORE_FIRST, intval($ad['inject_after_paragraph'] ?? 2));
                if ($p <= $para_count && !in_array($p, $slots)) $slots[] = $p;
            }
            sort($slots);
        }
        $slot_html = [];
        $t = 0;
        foreach ($slots as $slot_para) {
            $ad = $incontent_templates[$t % count($incontent_templates)];
            $slot_html[$slot_para] = tv_ads_build_html($ad);
            $t++;
        }
        $result = [];
        foreach ($parts as $i => $part) {
            $result[] = $part;
            if ($i < count($parts) - 1) {
                $result[] = '</p>';
                $para_num = $i + 1;
                if (isset($slot_html[$para_num])) {
                    $result[] = $slot_html[$para_num];
                }
            }
        }
        $content = implode('', $result);
    }
    return $header_ads . $content . $footer_ads;
}
// Build a SLOT (not a specific ad). Every slot is now a mediation slot:
// it carries only its position + size, and the footer script fills it via
// serve-slot (direct → network waterfall). GAM slot defs still supported.
function tv_ads_build_html($ad) {
    $wrap = 'text-align:center;margin:20px auto;clear:both;line-height:0;min-height:' . intval($ad['size_height'] ?? 250) . 'px;';
    $position = $ad['position'] ?? 'in_content';
    $w = intval($ad['size_width'] ?? 300);
    $h = intval($ad['size_height'] ?? 250);
    // A mediation slot. The footer waterfall fills it from serve-slot.
    return sprintf(
        '<div class="tv-lazy-ad" data-position="%s" data-w="%d" data-h="%d" style="%s"></div>' . "\n",
        esc_attr($position), $w, $h, esc_attr($wrap)
    );
}
// ── POPUNDER / PAGE-LEVEL SCRIPTS ────────────────────────────────
add_action('wp_head', 'tv_ads_inject_popunder', 6);
function tv_ads_inject_popunder() {
    if (get_option('tv_ads_enabled', '1') !== '1') return;
    $key = get_option('tv_ads_publisher_key', '');
    if (empty($key)) return;
    $cache_key = 'tv_popunder_' . md5(get_site_url());
    $codes = get_transient($cache_key);
    if ($codes === false) {
        $resp = wp_remote_get(add_query_arg([
            'key'  => $key,
            'site' => get_site_url(),
        ], TV_POPUNDER_API), [
            'timeout' => 8,
            'headers' => ['Accept' => 'application/json'],
        ]);
        $codes = [];
        if (!is_wp_error($resp) && wp_remote_retrieve_response_code($resp) === 200) {
            $data = json_decode(wp_remote_retrieve_body($resp), true);
            if (!empty($data['codes']) && is_array($data['codes'])) {
                $codes = $data['codes'];
            }
        }
        set_transient($cache_key, $codes, 3600);
    }
    if (empty($codes)) return;
    $blocked = ['casino','gambling','bet','poker','slots','lottery','adult','xxx','porn'];
    echo "\n<!-- TrendingVerse popunder -->\n";
    foreach ($codes as $code) {
        $low = strtolower($code);
        $bad = false;
        foreach ($blocked as $kw) { if (strpos($low, $kw) !== false) { $bad = true; break; } }
        if ($bad) continue;
        echo $code . "\n";
    }
    echo "<!-- /TrendingVerse popunder -->\n";
}
// ── MEDIATION WATERFALL LOADER ───────────────────────────────────
// Each .tv-lazy-ad slot calls serve-slot near the viewport and walks the
// returned demand list in order: direct first, then each network partner.
// Renders the first that fills; on network no-fill (heuristic), tries next.
// Per-partner impression + viewability tracking stays active throughout.
add_action('wp_footer', function () {
    if (get_option('tv_ads_enabled', '1') !== '1') return;
    ?>
<script>
(function () {
  'use strict';
  var SLOT   = '<?php echo esc_js(TV_SERVE_SLOT_API); ?>';
  var CLICK  = '<?php echo esc_js(TV_AD_CLICK_API); ?>';
  var VIEW   = '<?php echo esc_js(TV_AD_VIEW_API); ?>';
  var MEVENT = '<?php echo esc_js(TV_MEVENT_API); ?>';
  var SITE   = window.TV_SITE_URL || window.location.origin;
  function fp() { return window.tvFingerprint || localStorage.getItem('_tvfp') || ''; }

  function medEvent(position, partner, type) {
    try {
      fetch(MEVENT, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fingerprint: fp(), site_url: SITE, position: position || 'in_content', partner_slug: partner, event_type: type }),
        keepalive: true,
      }).catch(function(){});
    } catch (e) {}
  }

  var viewFired = {};
  function watchViewability(el, opts) {
    if (!('IntersectionObserver' in window)) return;
    var key = opts.adId || (opts.position + ':' + opts.partner + ':' + Math.random());
    var timer = null;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting && e.intersectionRatio >= 0.5) {
          if (!timer) timer = setTimeout(function () {
            if (viewFired[key]) return;
            viewFired[key] = true;
            medEvent(opts.position, opts.partner, 'viewable');
            if (opts.adId) {
              fetch(VIEW, { method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ad_id: opts.adId, fingerprint: fp(), site_url: SITE }), keepalive: true }).catch(function(){});
            }
            io.unobserve(el);
          }, 1000);
        } else if (timer) { clearTimeout(timer); timer = null; }
      });
    }, { threshold: [0, 0.5, 1] });
    io.observe(el);
  }

  // Did a network tag actually paint something into the slot?
  function networkFilled(slot) {
    if (slot.querySelector('iframe, ins, img')) return slot.getBoundingClientRect().height > 20;
    return slot.getBoundingClientRect().height > 20;
  }

  function renderDirect(slot, ad) {
    var w = parseInt(ad.size_width, 10) || 300;
    var h = parseInt(ad.size_height, 10) || 250;
    var wrap = document.createElement('div');
    wrap.className = 'tv-direct-ad';
    wrap.setAttribute('data-ad-id', ad.ad_id);
    wrap.style.cssText = 'max-width:' + w + 'px;margin:0 auto;border:1px solid #e5e7eb;border-radius:12px;overflow:hidden;background:#fff;cursor:pointer;line-height:1.4;text-align:left;font-family:inherit;';
    var html = '';
    if (ad.image_url) html += '<img src="' + ad.image_url + '" alt="" style="width:100%;display:block;max-height:' + h + 'px;object-fit:cover;" />';
    html += '<div style="padding:12px 14px;">';
    if (ad.headline)    html += '<p style="font-weight:700;font-size:14px;color:#111;margin:0 0 4px;">' + ad.headline + '</p>';
    if (ad.description) html += '<p style="font-size:12px;color:#666;margin:0 0 10px;">' + ad.description + '</p>';
    if (ad.cta_text)    html += '<span style="display:inline-block;background:#ef4444;color:#fff;font-size:12px;font-weight:600;padding:6px 14px;border-radius:6px;">' + ad.cta_text + '</span>';
    html += '</div><p style="font-size:9px;color:#bbb;text-align:right;margin:0;padding:0 8px 6px;">Ad</p>';
    wrap.innerHTML = html;
    wrap.addEventListener('click', function () {
      medEvent(slot.dataset.position, 'direct', 'click');
      fetch(CLICK, { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ad_id: ad.ad_id, fingerprint: fp(), site_url: SITE }), keepalive: true }).catch(function(){});
      if (ad.destination_url) window.open(ad.destination_url, '_blank', 'noopener');
    });
    slot.innerHTML = '';
    slot.appendChild(wrap);
    medEvent(slot.dataset.position, 'direct', 'impression');
    watchViewability(wrap, { adId: ad.ad_id, partner: 'direct', position: slot.dataset.position });
  }

  function injectNetwork(slot, code) {
    try {
      var range = document.createRange();
      range.selectNode(slot);
      slot.appendChild(range.createContextualFragment(code));
    } catch (e) {}
  }

  // Walk the demand list in order. Direct renders immediately. Network items
  // are injected and given ~2.5s to fill; if empty, move to the next partner.
  function serveDemand(slot, demand, idx) {
    if (idx >= demand.length) return; // nothing left filled
    var item = demand[idx];
    var position = slot.dataset.position || 'in_content';

    if (item.type === 'direct') {
      renderDirect(slot, item);
      return;
    }
    // network
    slot.innerHTML = '';
    injectNetwork(slot, item.ad_code || '');
    medEvent(position, item.source || 'network', 'impression');
    watchViewability(slot, { partner: item.source || 'network', position: position });
    // fill-check: if this network didn't paint, fall through to the next
    setTimeout(function () {
      if (!networkFilled(slot)) {
        serveDemand(slot, demand, idx + 1);
      }
    }, 2500);
  }

  function fillSlot(slot) {
    if (slot.dataset.filled === '1') return;
    slot.dataset.filled = '1';
    var position = slot.dataset.position || 'in_content';
    var w = parseInt(slot.dataset.w, 10) || 300;
    var h = parseInt(slot.dataset.h, 10) || 250;
    fetch(SLOT, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fingerprint: fp(), site_url: SITE, position: position, width: w, height: h }),
    })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var demand = (data && data.demand) || [];
        if (!demand.length) return; // no demand for this slot
        serveDemand(slot, demand, 0);
      })
      .catch(function () {});
  }

  var slots = document.querySelectorAll('.tv-lazy-ad');
  if (!slots.length) return;
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { fillSlot(e.target); io.unobserve(e.target); }
      });
    }, { rootMargin: '600px 0px' });
    slots.forEach(function (s) { io.observe(s); });
  } else {
    slots.forEach(fillSlot);
  }
})();
</script>
    <?php
});
// ── AUDIENCE TRACKING ─────────────────────────────────────────────
add_action('wp_head', 'tv_ads_inject_tracker', 5);
function tv_ads_inject_tracker() {
    $key              = get_option('tv_ads_publisher_key', '');
    $tracking_enabled = get_option('tv_ads_tracking_enabled', '1');
    if (empty($key) || $tracking_enabled !== '1') return;
    $category = '';
    if (is_single()) {
        $cats = get_the_category();
        if (!empty($cats)) $category = esc_js($cats[0]->name);
    }
    $site_url = esc_js(get_site_url());
    echo '<script>';
    echo 'window.TV_SITE_URL = "' . $site_url . '";';
    echo 'window.TV_CATEGORY = "' . $category . '";';
    echo '</script>';
    echo '<script src="https://trendingverse.vercel.app/tv-tracker.js" async defer></script>' . "\n";
}
// ── SCHEDULED TASKS ───────────────────────────────────────────────
register_activation_hook(__FILE__, function () {
    if (!wp_next_scheduled('tv_ads_hourly_refresh'))
        wp_schedule_event(time(), 'hourly', 'tv_ads_hourly_refresh');
});
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('tv_ads_hourly_refresh');
    delete_transient(TV_ADS_CACHE_KEY);
});
add_action('tv_ads_hourly_refresh', function () {
    tv_ads_fetch_codes(null, true);
});