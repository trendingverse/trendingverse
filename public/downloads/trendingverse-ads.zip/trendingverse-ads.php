<?php
/**
 * Plugin Name: TrendingVerse Ads
 * Plugin URI: https://trendingverse.vercel.app
 * Description: Connects this site to TrendingVerse. All ads are managed centrally in the TrendingVerse CMS — the site only needs its publisher key. Standard layout: in-article 300x250 after the 1st paragraph (+1 more on long articles), desktop leaderboard, bottom sticky 320x50, and a click-triggered interstitial for direct campaigns.
 * Version: 1.1.0
 * Author: TrendingVerse
 * Author URI: https://trendingverse.vercel.app
 * License: GPL2
 */
if (!defined('ABSPATH')) exit;
define('TV_ADS_VERSION',    '1.1.0');
define('TV_ADS_API',        'https://trendingverse.vercel.app/api/admin/publishers/ad-codes');
define('TV_ADS_UPDATE_URL', 'https://trendingverse.vercel.app/api/plugin/update-check');
define('TV_ADS_DOWNLOAD',   'https://trendingverse.vercel.app/api/plugin/download');
define('TV_SERVE_SLOT_API', 'https://trendingverse.vercel.app/api/mediation/serve-slot');
define('TV_AD_CLICK_API',   'https://trendingverse.vercel.app/api/audience/ad-click');
define('TV_AD_VIEW_API',    'https://trendingverse.vercel.app/api/audience/ad-viewable');
define('TV_MEVENT_API',     'https://trendingverse.vercel.app/api/mediation/event');
define('TV_POPUNDER_API',   'https://trendingverse.vercel.app/api/mediation/popunder');
define('TV_ADS_CACHE_KEY',  'tv_ads_cache');
define('TV_ADS_CACHE_TTL',  3600);

// ── STANDARD LAYOUT (same on every publisher site) ────────────────
define('TV_ADS_FIRST_PARA',      1);    // in-article unit after paragraph 1
define('TV_ADS_LONG_WORDS',      600);  // long article = at least this many words…
define('TV_ADS_LONG_MIN_PARAS',  6);    // …and this many paragraphs → one extra in-article unit
define('TV_ADS_STICKY_W',        320);
define('TV_ADS_STICKY_H',        50);
define('TV_ADS_LEADER_W',        728);  // default desktop leaderboard if the CMS has no header slot
define('TV_ADS_LEADER_H',        90);
define('TV_ADS_INTER_W',         300);
define('TV_ADS_INTER_H',         250);
define('TV_ADS_INTER_FREQ_MIN',  30);   // interstitial at most once per 30 min per reader
define('TV_ADS_INTER_CLOSE_SEC', 3);    // close button unlocks after 3 s

// ── AUTO-UPDATE MECHANISM ────────────────────────────────────────
add_filter('pre_set_site_transient_update_plugins', 'tv_ads_check_update');
function tv_ads_check_update($transient) {
    if (empty($transient->checked)) return $transient;
    $response = wp_remote_get(TV_ADS_UPDATE_URL, ['timeout' => 10, 'headers' => ['Accept' => 'application/json']]);
    if (is_wp_error($response)) return $transient;
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($data['version'])) return $transient;
    if (version_compare(TV_ADS_VERSION, $data['version'], '<')) {
        $transient->response['trendingverse-ads/trendingverse-ads.php'] = (object) [
            'slug'        => 'trendingverse-ads',
            'plugin'      => 'trendingverse-ads/trendingverse-ads.php',
            'new_version' => $data['version'],
            'url'         => 'https://trendingverse.vercel.app',
            'package'     => TV_ADS_DOWNLOAD,
        ];
    }
    return $transient;
}
add_filter('plugins_api', 'tv_ads_plugin_info', 20, 3);
function tv_ads_plugin_info($result, $action, $args) {
    if ($action !== 'plugin_information') return $result;
    if (!isset($args->slug) || $args->slug !== 'trendingverse-ads') return $result;
    $response = wp_remote_get(TV_ADS_UPDATE_URL . '?action=info', ['timeout' => 10, 'headers' => ['Accept' => 'application/json']]);
    if (is_wp_error($response)) return $result;
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($data)) return $result;
    return (object) [
        'name'          => $data['name']         ?? 'TrendingVerse Ads',
        'slug'          => 'trendingverse-ads',
        'version'       => $data['version']      ?? TV_ADS_VERSION,
        'author'        => $data['author']        ?? 'TrendingVerse',
        'last_updated'  => $data['last_updated']  ?? '',
        'requires'      => $data['requires']      ?? '5.0',
        'tested'        => $data['tested']        ?? '6.5',
        'download_link' => TV_ADS_DOWNLOAD,
        'sections'      => $data['sections']      ?? [],
    ];
}

// ── SETTINGS PAGE: publisher key only (no ad controls) ───────────
add_action('admin_menu', function () {
    add_options_page('TrendingVerse Ads', 'TrendingVerse Ads', 'manage_options', 'trendingverse-ads', 'tv_ads_settings_page');
});
add_action('admin_init', function () {
    register_setting('tv_ads_settings', 'tv_ads_publisher_key', ['sanitize_callback' => 'sanitize_text_field']);
});
function tv_ads_settings_page() {
    $key    = get_option('tv_ads_publisher_key', '');
    $status = tv_ads_test_connection($key);
    ?>
    <div class="wrap">
        <h1>TrendingVerse Ads <span style="font-size:12px;background:#111;color:#fff;padding:2px 8px;border-radius:20px;font-weight:400;">v<?php echo esc_html(TV_ADS_VERSION); ?></span></h1>
        <p style="color:#666;">Ads on this site are managed by TrendingVerse. Enter your publisher key to connect.</p>
        <?php if (isset($_GET['refreshed'])): ?>
        <div class="notice notice-info is-dismissible"><p>Refreshed.</p></div>
        <?php endif; ?>
        <?php if (!empty($key)): ?>
        <div class="notice notice-<?php echo $status['connected'] ? 'success' : 'error'; ?>" style="padding:12px 16px;">
            <strong><?php echo $status['connected'] ? '✓ Connected' : '✗ Not connected'; ?></strong> — <?php echo esc_html($status['message']); ?>
        </div>
        <?php endif; ?>
        <form method="post" action="options.php" style="margin-top:24px;">
            <?php settings_fields('tv_ads_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="tv_ads_publisher_key">Publisher Key</label></th>
                    <td>
                        <input type="text" id="tv_ads_publisher_key" name="tv_ads_publisher_key" value="<?php echo esc_attr($key); ?>"
                            style="width:420px;font-family:monospace;font-size:13px;" placeholder="tvp_xxxxxxxxxxxxxxxxxxxxxxxx" autocomplete="off" />
                        <p class="description">Provided by TrendingVerse.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save & Connect'); ?>
        </form>
        <?php if ($status['connected']): ?>
        <p>
            <a href="<?php echo esc_url(admin_url('options-general.php?page=trendingverse-ads&refresh=1')); ?>" class="button button-secondary">↺ Refresh</a>
            <a href="https://trendingverse.vercel.app/admin" target="_blank" rel="noopener" class="button" style="margin-left:6px;">View ad reports ↗</a>
        </p>
        <p class="description">If your site uses a page cache, purge it once after connecting.</p>
        <?php endif; ?>
    </div>
    <?php
}

// ── CONNECTION TEST ───────────────────────────────────────────────
function tv_ads_test_connection($key) {
    if (empty($key)) return ['connected' => false, 'message' => 'No key entered', 'ads' => []];
    $ads = tv_ads_fetch_codes($key, true);
    if (is_wp_error($ads)) return ['connected' => false, 'message' => $ads->get_error_message(), 'ads' => []];
    return ['connected' => true, 'message' => 'Ads are active for ' . get_site_url(), 'ads' => $ads];
}

// ── FETCH SLOT DEFINITIONS FROM THE CMS ───────────────────────────
function tv_ads_fetch_codes($key = null, $force = false) {
    if (!$key) $key = get_option('tv_ads_publisher_key', '');
    if (empty($key)) return [];
    if (!$force) {
        $cached = get_transient(TV_ADS_CACHE_KEY);
        if ($cached !== false) return $cached;
    }
    $response = wp_remote_get(add_query_arg(['key' => $key, 'site' => get_site_url()], TV_ADS_API), [
        'timeout' => 15,
        'headers' => ['Accept' => 'application/json', 'User-Agent' => 'TrendingVerse-Ads/' . TV_ADS_VERSION],
    ]);
    if (is_wp_error($response)) return new WP_Error('api_error', 'Connection failed: ' . $response->get_error_message());
    $code = wp_remote_retrieve_response_code($response);
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if ($code === 401) return new WP_Error('api_error', 'Invalid key');
    if ($code !== 200) return new WP_Error('api_error', 'Server returned status ' . $code);
    if (!isset($data['ads'])) return new WP_Error('api_error', 'Unexpected response');
    set_transient(TV_ADS_CACHE_KEY, $data['ads'], TV_ADS_CACHE_TTL);
    return $data['ads'];
}
add_action('admin_init', function () {
    if (isset($_GET['refresh']) && $_GET['refresh'] === '1' && current_user_can('manage_options')) {
        delete_transient(TV_ADS_CACHE_KEY);
        delete_transient('tv_popunder_' . md5(get_site_url()));
        tv_ads_fetch_codes(null, true);
        wp_redirect(admin_url('options-general.php?page=trendingverse-ads&refreshed=1'));
        exit;
    }
});

function tv_ads_active() {
    return get_option('tv_ads_publisher_key', '') !== '';
}

// Enabled CMS slot definitions for a position
function tv_ads_defs($position) {
    $ads = tv_ads_fetch_codes();
    if (empty($ads) || is_wp_error($ads)) return [];
    $out = [];
    foreach ($ads as $ad) {
        if (empty($ad['is_enabled'])) continue;
        if (($ad['position'] ?? '') === $position) $out[] = $ad;
    }
    return $out;
}

// A mediation slot: only position + size; the loader fills it from serve-slot.
// Units 468px or wider are desktop-only.
function tv_ads_slot($position, $w, $h) {
    $w = intval($w) ?: 300;
    $h = intval($h) ?: 250;
    $dev = $w >= 468 ? 'd' : 'all';
    $wrap = 'text-align:center;margin:20px auto;clear:both;line-height:0;max-width:100%;overflow:hidden;min-height:' . $h . 'px;';
    return sprintf(
        '<div class="tv-lazy-ad" data-position="%s" data-w="%d" data-h="%d" data-dev="%s" style="%s"></div>' . "\n",
        esc_attr($position), $w, $h, $dev, esc_attr($wrap)
    );
}

// ── AD INJECTION — standard layout ───────────────────────────────
add_filter('the_content', 'tv_ads_inject', 20);
function tv_ads_inject($content) {
    if (!is_single() || !in_the_loop() || !is_main_query() || !tv_ads_active()) return $content;

    // Desktop leaderboard at the top of the article (size from CMS "header" slot, else 728x90)
    $header = '';
    $hdefs = tv_ads_defs('header');
    if ($hdefs) {
        foreach ($hdefs as $d) $header .= tv_ads_slot('header', $d['size_width'] ?? TV_ADS_LEADER_W, $d['size_height'] ?? TV_ADS_LEADER_H);
    } else {
        $header = tv_ads_slot('header', TV_ADS_LEADER_W, TV_ADS_LEADER_H);
    }

    $footer = '';
    foreach (tv_ads_defs('footer') as $d) $footer .= tv_ads_slot('footer', $d['size_width'] ?? 300, $d['size_height'] ?? 250);

    // In-article: CMS in_content slots at their paragraph (default: after paragraph 1)
    $idefs = tv_ads_defs('in_content');
    if (!$idefs) $idefs = [['size_width' => 300, 'size_height' => 250, 'inject_after_paragraph' => TV_ADS_FIRST_PARA]];

    $parts = explode('</p>', $content);
    $paras = max(0, count($parts) - 1);
    $slot_html = [];

    foreach ($idefs as $d) {
        $p = max(1, intval($d['inject_after_paragraph'] ?? TV_ADS_FIRST_PARA));
        if ($paras === 0 && $p === 1) { $footer = tv_ads_slot('in_content', $d['size_width'] ?? 300, $d['size_height'] ?? 250) . $footer; continue; }
        if ($p <= $paras) $slot_html[$p] = ($slot_html[$p] ?? '') . tv_ads_slot('in_content', $d['size_width'] ?? 300, $d['size_height'] ?? 250);
    }

    // Long article → one extra in-article unit in the middle
    if ($paras >= TV_ADS_LONG_MIN_PARAS) {
        $text  = trim(wp_strip_all_tags(strip_shortcodes($content)));
        $words = $text === '' ? 0 : count(preg_split('/\s+/u', $text)); // space-based: works for Kannada/Indic
        if ($words >= TV_ADS_LONG_WORDS) {
            $mid = max(3, (int) ceil($paras / 2));
            while (isset($slot_html[$mid]) || isset($slot_html[$mid - 1]) || isset($slot_html[$mid + 1])) $mid++;
            if ($mid < $paras) {
                $first = $idefs[0];
                $slot_html[$mid] = tv_ads_slot('in_content', $first['size_width'] ?? 300, $first['size_height'] ?? 250);
            }
        }
    }

    if ($slot_html) {
        $result = [];
        foreach ($parts as $i => $part) {
            $result[] = $part;
            if ($i < count($parts) - 1) {
                $result[] = '</p>';
                if (isset($slot_html[$i + 1])) $result[] = $slot_html[$i + 1];
            }
        }
        $content = implode('', $result);
    }
    return $header . $content . $footer;
}

// ── POPUNDER / PAGE-LEVEL SCRIPTS (managed in the CMS) ───────────
add_action('wp_head', 'tv_ads_inject_popunder', 6);
function tv_ads_inject_popunder() {
    if (!tv_ads_active()) return;
    $key = get_option('tv_ads_publisher_key', '');
    $cache_key = 'tv_popunder_' . md5(get_site_url());
    $codes = get_transient($cache_key);
    if ($codes === false) {
        $resp = wp_remote_get(add_query_arg(['key' => $key, 'site' => get_site_url()], TV_POPUNDER_API), [
            'timeout' => 8, 'headers' => ['Accept' => 'application/json'],
        ]);
        $codes = [];
        if (!is_wp_error($resp) && wp_remote_retrieve_response_code($resp) === 200) {
            $data = json_decode(wp_remote_retrieve_body($resp), true);
            if (!empty($data['codes']) && is_array($data['codes'])) $codes = $data['codes'];
        }
        set_transient($cache_key, $codes, 3600);
    }
    if (empty($codes)) return;
    $blocked = ['casino','gambling','bet','poker','slots','lottery','adult','xxx','porn'];
    foreach ($codes as $code) {
        $low = strtolower($code);
        $bad = false;
        foreach ($blocked as $kw) { if (strpos($low, $kw) !== false) { $bad = true; break; } }
        if (!$bad) echo $code . "\n";
    }
}

// ── STYLES for sticky + interstitial ─────────────────────────────
add_action('wp_head', function () {
    if (!tv_ads_active()) return;
    ?>
<style id="tv-ads-css">
#tv-sticky{position:fixed;left:0;right:0;bottom:0;z-index:2147483000;display:flex;justify-content:center;pointer-events:none;padding-bottom:env(safe-area-inset-bottom)}
#tv-sticky .tv-sticky-box{position:relative;pointer-events:auto;background:#fff;box-shadow:0 -2px 10px rgba(0,0,0,.18);padding:2px;border-radius:4px 4px 0 0}
#tv-sticky .tv-lazy-ad{margin:0 !important}
#tv-sticky .tv-x{position:absolute;top:-22px;right:0;width:26px;height:22px;border:0;border-radius:4px 4px 0 0;background:#fff;color:#333;font:18px/22px Arial,sans-serif;cursor:pointer;box-shadow:0 -2px 6px rgba(0,0,0,.15);padding:0}
body.tv-has-sticky{padding-bottom:64px !important}
#tv-inter{position:fixed;inset:0;z-index:2147483600;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.78);padding:16px}
#tv-inter .tv-inter-box{background:#fff;border-radius:8px;padding:10px 12px 12px;max-width:100%;max-height:100%;overflow:auto;box-shadow:0 8px 30px rgba(0,0,0,.4);text-align:center;min-width:280px}
#tv-inter .tv-inter-bar{display:flex;align-items:center;gap:10px;margin-bottom:8px;font:12px/1.4 Arial,sans-serif;color:#888}
#tv-inter .tv-inter-label{text-transform:uppercase;letter-spacing:.5px;flex:1;text-align:left}
#tv-inter .tv-x{width:32px;height:32px;border:0;border-radius:50%;background:#222;color:#fff;font:22px/32px Arial,sans-serif;cursor:pointer;padding:0}
#tv-inter .tv-x:disabled,#tv-inter .tv-skip:disabled{opacity:.35;cursor:default}
#tv-inter .tv-skip{margin-top:10px;border:0;background:none;color:#0a66c2;font:600 14px/1.4 Arial,sans-serif;cursor:pointer}
#tv-inter .tv-inter-slot{min-height:250px;display:flex;align-items:center;justify-content:center}
html.tv-lock,html.tv-lock body{overflow:hidden}
</style>
    <?php
}, 7);

// ── MEDIATION WATERFALL LOADER ───────────────────────────────────
add_action('wp_footer', function () {
    if (!tv_ads_active()) return;
    ?>
<script>
(function () {
  'use strict';
  var SLOT   = '<?php echo esc_js(TV_SERVE_SLOT_API); ?>';
  var CLICK  = '<?php echo esc_js(TV_AD_CLICK_API); ?>';
  var VIEW   = '<?php echo esc_js(TV_AD_VIEW_API); ?>';
  var MEVENT = '<?php echo esc_js(TV_MEVENT_API); ?>';
  var SITE   = window.TV_SITE_URL || window.location.origin;
  var MOBILE = !!(window.matchMedia && window.matchMedia('(max-width: 767px)').matches);
  var STICKY = { w: <?php echo (int) TV_ADS_STICKY_W; ?>, h: <?php echo (int) TV_ADS_STICKY_H; ?> };
  var INTER  = { w: <?php echo (int) TV_ADS_INTER_W; ?>, h: <?php echo (int) TV_ADS_INTER_H; ?>, freq: <?php echo (int) TV_ADS_INTER_FREQ_MIN; ?>, close: <?php echo (int) TV_ADS_INTER_CLOSE_SEC; ?> };
  function fp() { try { return window.tvFingerprint || localStorage.getItem('_tvfp') || ''; } catch (e) { return ''; } }
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, String(v)); } catch (e) {} return null; }

  function medEvent(position, partner, type) {
    try {
      fetch(MEVENT, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fingerprint: fp(), site_url: SITE, position: position || 'in_content', partner_slug: partner, event_type: type }),
        keepalive: true,
      }).catch(function(){});
    } catch (e) {}
  }

  var viewFired = {};
  function watchViewability(el, opts) {
    if (!('IntersectionObserver' in window)) return;
    var key = opts.adId ? (opts.adId + ':' + opts.position) : (opts.position + ':' + opts.partner + ':' + Math.random());
    var timer = null;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting && e.intersectionRatio >= 0.5) {
          if (!timer) timer = setTimeout(function () {
            if (viewFired[key]) return;
            viewFired[key] = true;
            medEvent(opts.position, opts.partner, 'viewable');
            if (opts.adId) {
              fetch(VIEW, { method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ad_id: opts.adId, fingerprint: fp(), site_url: SITE }), keepalive: true }).catch(function(){});
            }
            io.unobserve(el);
          }, 1000);
        } else if (timer) { clearTimeout(timer); timer = null; }
      });
    }, { threshold: [0, 0.5, 1] });
    io.observe(el);
  }

  function networkFilled(slot) {
    return slot.getBoundingClientRect().height > 20;
  }

  function esc(s) { return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

  function renderDirect(slot, ad) {
    var w = parseInt(slot.dataset.w, 10) || parseInt(ad.size_width, 10) || 300;
    var h = parseInt(slot.dataset.h, 10) || parseInt(ad.size_height, 10) || 250;
    var compact = h <= 100; // sticky / leaderboard: banner only, no text card
    var wrap = document.createElement('div');
    wrap.className = 'tv-direct-ad';
    wrap.setAttribute('data-ad-id', ad.ad_id);
    var html = '';
    if (compact) {
      wrap.style.cssText = 'width:' + w + 'px;max-width:100%;height:' + h + 'px;margin:0 auto;overflow:hidden;cursor:pointer;background:#fff;display:flex;align-items:center;justify-content:center;line-height:1.2;font-family:inherit;';
      if (ad.image_url) html = '<img src="' + esc(ad.image_url) + '" alt="" style="width:100%;height:100%;object-fit:cover;display:block;" />';
      else html = '<span style="font-weight:700;font-size:13px;color:#111;padding:0 8px;">' + esc(ad.headline) + '</span>' + (ad.cta_text ? '<span style="background:#ef4444;color:#fff;font-size:12px;font-weight:600;padding:5px 10px;border-radius:6px;white-space:nowrap;">' + esc(ad.cta_text) + '</span>' : '');
    } else {
      wrap.style.cssText = 'max-width:' + w + 'px;margin:0 auto;border:1px solid #e5e7eb;border-radius:12px;overflow:hidden;background:#fff;cursor:pointer;line-height:1.4;text-align:left;font-family:inherit;';
      if (ad.image_url) html += '<img src="' + esc(ad.image_url) + '" alt="" style="width:100%;display:block;max-height:' + h + 'px;object-fit:cover;" />';
      html += '<div style="padding:12px 14px;">';
      if (ad.headline)    html += '<p style="font-weight:700;font-size:14px;color:#111;margin:0 0 4px;">' + esc(ad.headline) + '</p>';
      if (ad.description) html += '<p style="font-size:12px;color:#666;margin:0 0 10px;">' + esc(ad.description) + '</p>';
      if (ad.cta_text)    html += '<span style="display:inline-block;background:#ef4444;color:#fff;font-size:12px;font-weight:600;padding:6px 14px;border-radius:6px;">' + esc(ad.cta_text) + '</span>';
      html += '</div><p style="font-size:9px;color:#bbb;text-align:right;margin:0;padding:0 8px 6px;">Ad</p>';
    }
    wrap.innerHTML = html;
    wrap.addEventListener('click', function (ev) {
      ev.stopPropagation();
      medEvent(slot.dataset.position, 'direct', 'click');
      fetch(CLICK, { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ad_id: ad.ad_id, fingerprint: fp(), site_url: SITE }), keepalive: true }).catch(function(){});
      if (ad.destination_url) window.open(ad.destination_url, '_blank', 'noopener');
    });
    slot.innerHTML = '';
    slot.appendChild(wrap);
    medEvent(slot.dataset.position, 'direct', 'impression');
    watchViewability(wrap, { adId: ad.ad_id, partner: 'direct', position: slot.dataset.position });
  }

  function injectNetwork(slot, code) {
    try {
      var range = document.createRange();
      range.selectNode(slot);
      slot.appendChild(range.createContextualFragment(code));
    } catch (e) {}
  }

  // Walk the demand list: direct first, then network partners with no-fill fallback.
  function serveDemand(slot, demand, idx, onEmpty) {
    if (idx >= demand.length) { if (onEmpty) onEmpty(); return; }
    var item = demand[idx];
    var position = slot.dataset.position || 'in_content';
    if (item.type === 'direct') { renderDirect(slot, item); return; }
    slot.innerHTML = '';
    injectNetwork(slot, item.ad_code || '');
    medEvent(position, item.source || 'network', 'impression');
    watchViewability(slot, { partner: item.source || 'network', position: position });
    setTimeout(function () {
      if (!networkFilled(slot)) serveDemand(slot, demand, idx + 1, onEmpty);
    }, 2500);
  }

  function requestSlot(position, w, h) {
    return fetch(SLOT, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fingerprint: fp(), site_url: SITE, position: position, width: w, height: h }),
    }).then(function (r) { return r.json(); }).then(function (d) { return (d && d.demand) || []; });
  }

  function fillSlot(slot, onEmpty) {
    if (slot.dataset.filled === '1') return;
    slot.dataset.filled = '1';
    var w = parseInt(slot.dataset.w, 10) || 300;
    var h = parseInt(slot.dataset.h, 10) || 250;
    requestSlot(slot.dataset.position || 'in_content', w, h)
      .then(function (demand) {
        if (!demand.length) { if (onEmpty) onEmpty(); return; }
        serveDemand(slot, demand, 0, onEmpty);
      })
      .catch(function () { if (onEmpty) onEmpty(); });
  }

  // ── in-article / header / footer slots ──
  var slots = Array.prototype.slice.call(document.querySelectorAll('.tv-lazy-ad'));
  slots = slots.filter(function (s) {
    if (MOBILE && s.dataset.dev === 'd') { s.parentNode && s.parentNode.removeChild(s); return false; }
    return true;
  });
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) { fillSlot(e.target); io.unobserve(e.target); } });
    }, { rootMargin: '600px 0px' });
    slots.forEach(function (s) { io.observe(s); });
  } else {
    slots.forEach(function (s) { fillSlot(s); });
  }

  // ── bottom sticky 320x50 (mobile + desktop) ──
  (function sticky() {
    var wrap = document.createElement('div');
    wrap.id = 'tv-sticky';
    wrap.innerHTML = '<div class="tv-sticky-box"><button type="button" class="tv-x" aria-label="Close ad">&times;</button><div class="tv-lazy-ad" data-position="sticky" data-w="' + STICKY.w + '" data-h="' + STICKY.h + '" style="line-height:0;min-height:' + STICKY.h + 'px;width:' + STICKY.w + 'px;max-width:100vw;overflow:hidden;"></div></div>';
    wrap.style.display = 'none';
    document.body.appendChild(wrap);
    var slot = wrap.querySelector('.tv-lazy-ad');
    function close() { if (wrap.parentNode) wrap.parentNode.removeChild(wrap); document.body.classList.remove('tv-has-sticky'); }
    wrap.querySelector('.tv-x').addEventListener('click', close);
    wrap.style.display = '';
    document.body.classList.add('tv-has-sticky');
    fillSlot(slot, close); // nothing to serve → remove the bar
  })();

  // ── interstitial on internal link click (direct campaigns only) ──
  (function interstitial() {
    document.addEventListener('click', function (e) {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      var a = e.target.closest ? e.target.closest('a[href]') : null;
      if (!a || a.closest('.tv-lazy-ad, #tv-inter, #tv-sticky, #wpadminbar')) return;
      if ((a.target && a.target !== '_self') || a.hasAttribute('download')) return;
      var url;
      try { url = new URL(a.href, location.href); } catch (x) { return; }
      if (url.origin !== location.origin || !/^https?:$/.test(url.protocol)) return;
      if (url.pathname === location.pathname && url.search === location.search) return;
      if (/\/wp-(admin|login)|\.(pdf|jpe?g|png|gif|webp|zip)$/i.test(url.pathname)) return;
      if (document.body.classList.contains('logged-in')) return;
      if (Date.now() < (+ls('tv_int_next') || 0)) return;
      e.preventDefault();
      show(url.href);
    });

    function show(href) {
      var gone = false;
      function go() { if (!gone) { gone = true; location.href = href; } }
      var failSafe = setTimeout(function () { ls('tv_int_next', Date.now() + 5 * 60000); go(); }, 2500);
      requestSlot('interstitial', INTER.w, INTER.h).then(function (demand) {
        var ad = null;
        for (var i = 0; i < demand.length; i++) if (demand[i].type === 'direct') { ad = demand[i]; break; }
        if (gone) return;
        clearTimeout(failSafe);
        if (!ad) { ls('tv_int_next', Date.now() + 5 * 60000); go(); return; } // no direct campaign: go straight on
        ls('tv_int_next', Date.now() + INTER.freq * 60000);

        var wrap = document.createElement('div');
        wrap.id = 'tv-inter';
        wrap.setAttribute('role', 'dialog');
        wrap.setAttribute('aria-modal', 'true');
        wrap.innerHTML = '<div class="tv-inter-box"><div class="tv-inter-bar"><span class="tv-inter-label">Advertisement</span><span class="tv-count"></span><button type="button" class="tv-x" aria-label="Close ad and continue">&times;</button></div><div class="tv-inter-slot"><div class="tv-lazy-ad" data-position="interstitial" data-w="' + INTER.w + '" data-h="' + INTER.h + '" style="line-height:0;"></div></div><button type="button" class="tv-skip">Continue &rarr;</button></div>';
        document.body.appendChild(wrap);
        document.documentElement.classList.add('tv-lock');
        renderDirect(wrap.querySelector('.tv-lazy-ad'), ad);

        var x = wrap.querySelector('.tv-x'), skip = wrap.querySelector('.tv-skip'), cnt = wrap.querySelector('.tv-count');
        var armed = false, d = INTER.close;
        function tryGo() { if (armed) go(); }
        function arm() { armed = true; x.disabled = false; skip.disabled = false; cnt.textContent = ''; }
        x.onclick = tryGo; skip.onclick = tryGo;
        document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') tryGo(); });
        if (d > 0) {
          x.disabled = true; skip.disabled = true; cnt.textContent = 'Close in ' + d + 's';
          var iv = setInterval(function () { d--; if (d <= 0) { clearInterval(iv); arm(); } else cnt.textContent = 'Close in ' + d + 's'; }, 1000);
        } else arm();
      }).catch(function () { clearTimeout(failSafe); go(); });
    }
  })();
})();
</script>
    <?php
});

// ── AUDIENCE TRACKING (managed centrally) ─────────────────────────
add_action('wp_head', 'tv_ads_inject_tracker', 5);
function tv_ads_inject_tracker() {
    if (!tv_ads_active()) return;
    $category = '';
    if (is_single()) {
        $cats = get_the_category();
        if (!empty($cats)) $category = esc_js($cats[0]->name);
    }
    echo '<script>window.TV_SITE_URL="' . esc_js(get_site_url()) . '";window.TV_CATEGORY="' . $category . '";</script>';
    echo '<script src="https://trendingverse.vercel.app/tv-tracker.js" async defer></script>' . "\n";
}

// ── SCHEDULED TASKS ───────────────────────────────────────────────
register_activation_hook(__FILE__, function () {
    if (!wp_next_scheduled('tv_ads_hourly_refresh')) wp_schedule_event(time(), 'hourly', 'tv_ads_hourly_refresh');
});
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('tv_ads_hourly_refresh');
    delete_transient(TV_ADS_CACHE_KEY);
});
add_action('tv_ads_hourly_refresh', function () {
    tv_ads_fetch_codes(null, true);
});