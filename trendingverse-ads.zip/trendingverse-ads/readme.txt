=== TrendingVerse Ads ===
Version: 1.0.2
Requires at least: 5.0
Tested up to: 6.5
Requires PHP: 7.4

== Description ==
Automatically fetches and injects monetization ads from TrendingVerse CMS.
Self-updating — updates automatically when new versions are released.

== Installation ==
1. Upload trendingverse-ads folder to /wp-content/plugins/
2. Activate plugin
3. Settings → TrendingVerse Ads → Enter API Key → Save

== Changelog ==
= 1.0.2 = Self-update mechanism added, removed ad names from display
= 1.0.1 = Fixed API endpoint
= 1.0.0 = Initial release
